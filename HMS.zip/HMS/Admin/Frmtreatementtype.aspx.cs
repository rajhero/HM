﻿using HMS.DAL;
using HMS.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HMS.Admin
{

    public partial class Frmtreatementtype : System.Web.UI.Page
    {

        private static int _treatmenttypeid;

        public static int Treatmenttypeid { get => _treatmenttypeid; set => _treatmenttypeid = value; }
        private UnitOfWork objUnitOfWork = new UnitOfWork();
        private ServiceModel objServiceModel = new ServiceModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["controllerID"] != null)
            {
                if (!this.IsPostBack)
                {
                    Gettreatmenttypedetails(); Clear();
                }
            }
        }

        private void Clear() { txttreatmenttypeName.Text = txttreatmentdescription.Text = txttreatmentdays.Text = string.Empty; }

        private void Gettreatmenttypedetails()
        {
            var source = objUnitOfWork.tbltreatementtypeRepository.Get().OrderBy(d => d.treatmenttype);
            bool any = source.Any();

            if (!any)
            {
                treatmenttypeview.EmptyDataText = "No records found!!";
            }
            else
            {
                if (treatmenttypeview != null)
                {
                    treatmenttypeview.DataSource = source;
                    treatmenttypeview.DataBind();
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (btnSubmit.Text == "Submit")
            {
                tbltreatementtype tbltreatementtype = new tbltreatementtype
                {




                    treatmenttype = txttreatmenttypeName.Text,
                    treatmentdays = Convert.ToInt32(txttreatmentdays.Text),
                    treatmentdescription = txttreatmentdescription.Text,

                };
                objUnitOfWork.tbltreatementtypeRepository.Insert(tbltreatementtype);
                if (objUnitOfWork.Save() > 0)
                {
                    Gettreatmenttypedetails();
                    lblMsg.Text = "Records successfully inserted";
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
            else if (btnSubmit.Text == "Edit")
            {
                tbltreatementtype tbltreatementtype = new tbltreatementtype();
                tbltreatementtype = objUnitOfWork.tbltreatementtypeRepository.GetByID(Treatmenttypeid);
                tbltreatementtype.treatmenttype = txttreatmenttypeName.Text;
                tbltreatementtype.treatmentdays = Convert.ToInt32(txttreatmentdays.Text);
                tbltreatementtype.treatmentdescription = txttreatmentdescription.Text;

                objUnitOfWork.tbltreatementtypeRepository.Update(tbltreatementtype);
                if (objUnitOfWork.Save() > 0)
                {
                    lblMsg.Text = "Records successfully inserted";
                    Gettreatmenttypedetails();
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
            btnSubmit.Text = "Submit";
        }

        protected void lnkedit_Click(object sender, EventArgs e)
        {
            Treatmenttypeid = int.Parse((((LinkButton)sender).CommandArgument).ToString());
            GridViewRow grdViewRow = (GridViewRow)((LinkButton)sender).Parent.Parent;
            txttreatmenttypeName.Text = grdViewRow.Cells[1].Text;
            txttreatmentdays.Text = grdViewRow.Cells[2].Text;
            txttreatmentdescription.Text = grdViewRow.Cells[3].Text;
            btnSubmit.Text = "Edit";
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            Treatmenttypeid = int.Parse((((LinkButton)sender).CommandArgument).ToString());


            objUnitOfWork.tbltreatementtypeRepository.Delete(Treatmenttypeid);
            if (objUnitOfWork.Save() > 0)
            {
                lblMsg.Text = "Records successfully removed";
                Gettreatmenttypedetails();
            }
            else { lblMsg.Text = "Server Interrupted!!"; }

        }
    }
}