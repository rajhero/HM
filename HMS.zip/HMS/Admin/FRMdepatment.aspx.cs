﻿using HMS.DAL;
using HMS.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HMS.Admin
{
    public partial class FRMdepatment : System.Web.UI.Page
    {

        private static int _departmenttypeID;

        public static int DepartmenttypeID
        {
            get { return _departmenttypeID; }
            set { _departmenttypeID = value; }
        }

        private UnitOfWork objUnitOfWork = new UnitOfWork();
        private ServiceModel objServiceModel = new ServiceModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["controllerID"] != null)
            {
                if (!this.IsPostBack)
                {
                    Getdepartmenttypedetails(); Clear();
                }
            }
        }

        private void Clear() => txtDepartmentName.Text = string.Empty;

        private void Getdepartmenttypedetails()
        {
            var source = objServiceModel.tbldepartments.OrderBy(d => d.departmentID);
            bool any = source.Any();

            if (!any)
            {
                Departmentview.EmptyDataText = "No records found!!";
            }
            else
            {
                if (Departmentview != null)
                {
                    Departmentview.DataSource = source.ToList();
                    Departmentview.DataBind();
                }
            }
        }
        

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (btnSubmit.Text == "Submit")
            {
                tbldepartment tbldepartment = new tbldepartment();

                tbldepartment.departmentname = txtDepartmentName.Text;
                
                objServiceModel.tbldepartments.Add(tbldepartment);
                if (objServiceModel.SaveChanges() > 0)
                {
                    Getdepartmenttypedetails();
                    lblMsg.Text = "Records successfully inserted";
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
            else if (btnSubmit.Text == "Edit")
            {
                tbldepartment tbldepartment = new tbldepartment();
                tbldepartment = objServiceModel.tbldepartments.SingleOrDefault(d=>d.departmentID==DepartmenttypeID);
                tbldepartment.departmentname = txtDepartmentName.Text;
                //objServiceModel.tbldepartments.Update(tbldepartment);
                if (objServiceModel.SaveChanges() > 0)
                {
                    lblMsg.Text = "Records successfully inserted";
                    Getdepartmenttypedetails();
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
            btnSubmit.Text = "Submit";
        }

        protected void lnkedit_Click(object sender, EventArgs e)
        {
            DepartmenttypeID = int.Parse((((LinkButton)sender).CommandArgument).ToString());
            GridViewRow grdViewRow = (GridViewRow)((LinkButton)sender).Parent.Parent;
            txtDepartmentName.Text = grdViewRow.Cells[1].Text;
            btnSubmit.Text = "Edit";
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            DepartmenttypeID = int.Parse((((LinkButton)sender).CommandArgument).ToString());
            tbldepartment tbldepartment = new tbldepartment();
            tbldepartment = objServiceModel.tbldepartments.SingleOrDefault(d => d.departmentID == DepartmenttypeID);

            objServiceModel.tbldepartments.Remove(tbldepartment);
            if (objServiceModel.SaveChanges() > 0)
            {
                lblMsg.Text = "Records successfully removed";
                Getdepartmenttypedetails();
            }
            else { lblMsg.Text = "Server Interrupted!!"; }

        }
    }
}