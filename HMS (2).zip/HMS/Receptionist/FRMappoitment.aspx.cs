﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HMS.DAL;
using HMS.Model;

namespace HMS.Receptionist
{


    public partial class FRMappoitment : System.Web.UI.Page
    {

        private static int _appointmentid;

        public static int Appointmentid { get => _appointmentid; set => _appointmentid = value; }
        private UnitOfWork objUnitOfWork = new UnitOfWork();
        private ServiceModel objServiceModel = new ServiceModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["controllerID"] != null)
            {
                if (!this.IsPostBack)
                {

                    GetTblappointmentdetail(); Clear();
                    Getpatient();
                    Getdoctor();
                }
            }
        }

        private void Getdoctor()
        {
            var source = objUnitOfWork.TblaccountRepository.Get().
                Join(objServiceModel.TBLdesignations,
                    ac=>ac.designationid,
                    de=>de.DesignationID,
                    (ac,de)=>
                        new
                        {
                            designationid= ac.designationid,
                            Designation=de.Designation,
                            loginID=ac.loginID,
                            docname= ac.name
                        }).
                Where(d=>d.Designation.ToLower()=="doctor").
                OrderBy(d => d.designationid);

            if (source.Any())
            {
                ddlDoctor.DataSource = source;
                ddlDoctor.DataTextField = "docname";
                ddlDoctor.DataValueField = "loginID";
                ddlDoctor.DataBind(); 
            }

        }

        private void Getpatient()
        {
            var source = objUnitOfWork.Tblpatient.Get().OrderBy(d => d.patientid);
            if (source.Any())
            {
                ddlpatient.DataSource = source;
                ddlpatient.DataTextField = "name";
                ddlpatient.DataValueField = "patientid";
                ddlpatient.DataBind();
            }
        }

        private void Clear()
        {
            txtendtime.Text = txtstarttime.Text = string.Empty;
            ddlpatient.SelectedIndex = ddlDoctor.SelectedIndex = ddllocation.SelectedIndex = 0;
        }


        private void GetTblappointmentdetail()
        {
            var source =  objUnitOfWork.tblappointment.Get().
                 Join(objServiceModel.tblappointments,
                    ac => ac.appointmentid,
                    de => de.appointmentid,
                    (ac, de) =>
                        new
                        {
                            appointmentid = ac.appointmentid,
                            doctor = de.doctor,
                            patientid = de.patientid,
                            starttime = de.starttime,
                            endtime = de.endtime,

                            location = de.location



                        }).Join(objServiceModel.TBLpatients,
                    ac => ac.patientid,
                    de => de.patientid,
                    (ac, de) =>
                        new
                        {
                            appointmentid = ac.appointmentid,
                            doctor = ac.doctor,
                            patientid = ac.patientid,
                            starttime = ac.starttime,
                            endtime = ac.endtime,
                            location = ac.location,
                            patientname = de.name


                        }).Join(objServiceModel.TBLaccounts,
                    ac => ac.doctor,
                    de => de.loginID,
                    (ac, de) =>
                        new
                        {
                            appointmentid = ac.appointmentid,
                            patientid = ac.patientid,
                            starttime = ac.starttime,
                            endtime = ac.endtime,
                            location = ac.location,
                            patientname = de.name,
                            doctorname = de.name,
                            appoitmentdatetime = ac.starttime + "-" + ac.endtime,


                        }).OrderBy(d => d.appointmentid);
            if (source.Any())
            {
                appointmentview.DataSource = source;
                appointmentview.DataBind();
            }
            else
            {
                appointmentview.EmptyDataText = "No records found!!";
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (btnSubmit.Text == "Submit")
            {
                //add blood group ,type
                tblappointment tblappointment = new tblappointment
                {

                    doctor = ddlDoctor.SelectedItem.Value,
                    location = ddllocation.SelectedItem.Value,
                    starttime = DateTime.Parse(txtstarttime.Text),
                    endtime = DateTime.Parse(txtendtime.Text),
                    patientid = Convert.ToInt32(ddlpatient.SelectedItem.Value),

                };
                objUnitOfWork.tblappointment.Insert(tblappointment);
                if (objUnitOfWork.Save() > 0)
                {
                    lblMsg.Text = "Records successfully inserted";
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
            else if (btnSubmit.Text == "Edit")
            {
                tblappointment tblappointment = new tblappointment();
                tblappointment = objUnitOfWork.tblappointment.GetByID(_appointmentid);

                tblappointment.doctor = ddlDoctor.SelectedItem.Value;
                tblappointment.location = ddllocation.SelectedItem.Value;
                tblappointment.starttime = DateTime.Parse(txtstarttime.Text);
                tblappointment.endtime = DateTime.Parse(txtendtime.Text);
                tblappointment.patientid = Convert.ToInt32(ddlpatient.SelectedItem.Value);

                objUnitOfWork.tblappointment.Update(tblappointment);

                if (objUnitOfWork.Save() > 0)
                {
                    lblMsg.Text = "Records successfully inserted";
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
            btnSubmit.Text = "Submit";
        }

        protected void lnkedit_Click(object sender, EventArgs e)
        {
            _appointmentid = int.Parse((((LinkButton)sender).CommandArgument).ToString());
            GridViewRow grdViewRow = (GridViewRow)((LinkButton)sender).Parent.Parent;
            ddlpatient.SelectedIndex = ddlpatient.Items.IndexOf(ddlpatient.Items.FindByValue(grdViewRow.Cells[0].Text));
            txtstarttime.Text = grdViewRow.Cells[1].Text;
            txtendtime.Text = grdViewRow.Cells[2].Text;
            ddlDoctor.SelectedIndex = ddlDoctor.Items.IndexOf(ddlDoctor.Items.FindByValue(grdViewRow.Cells[3].Text));
            ddllocation.SelectedIndex = ddllocation.Items.IndexOf(ddllocation.Items.FindByValue(grdViewRow.Cells[3].Text));
            btnSubmit.Text = "Edit";
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            _appointmentid = int.Parse((((LinkButton)sender).CommandArgument).ToString());
            objUnitOfWork.tblappointment.Delete(_appointmentid);
            objUnitOfWork.Save();

        }
    }
}