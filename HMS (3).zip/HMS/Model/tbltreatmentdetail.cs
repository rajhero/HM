namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class tbltreatmentdetail
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public tbltreatmentdetail()
        {
            tbltreatmenttabletdetails = new HashSet<tbltreatmenttabletdetail>();
        }

        [Key]
        public int treatmentdetailsid { get; set; }

        public int treamentid { get; set; }

        public int deseaseid { get; set; }

        public string treatmentdetails { get; set; }

        public virtual TBLdisease TBLdisease { get; set; }

        public virtual tbltreatment tbltreatment { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tbltreatmenttabletdetail> tbltreatmenttabletdetails { get; set; }
    }
}
