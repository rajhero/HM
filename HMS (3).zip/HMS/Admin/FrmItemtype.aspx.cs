﻿using HMS.DAL;
using HMS.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HMS.Admin
{
    public partial class FrmItemtype : System.Web.UI.Page
    {

        private static int _itemtypeID;

        public static int itemtypeID
        {
            get { return _itemtypeID; }
            set { _itemtypeID = value; }
        }

        private UnitOfWork objUnitOfWork = new UnitOfWork();
        private ServiceModel objServiceModel = new ServiceModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["controllerID"] != null)
            {
                if (!this.IsPostBack)
                {
                    GetItemtypedetails();  filldeptartment(); Clear();
                }
            }
        }

        private void Clear() { txtitemTypeName.Text = string.Empty; ddldepartment.SelectedIndex = 0; }
        private void filldeptartment() {
            var source = objUnitOfWork.tbldepartmentRepository.Get();

            if (source.Any())
            {

                ddldepartment.DataSource = source;
                ddldepartment.DataTextField = "departmentname";
                ddldepartment.DataValueField = "departmentID";
                ddldepartment.DataBind();
            }
            ddldepartment.Items.Insert(0, "Select");
        }

        private void GetItemtypedetails()
        {
            var source = objUnitOfWork.tblItemtypeRepository.Get()
                .Join(
                objServiceModel.tbldepartments,
                itemty => itemty.departmentid,
                dept => dept.departmentID,
                (itemty, dept) => new
                {
                    departmentid = itemty.departmentid,
                    itemtype = itemty.itemtype,
                    itemtypeid = itemty.itemtypeid,
                    departmentname = dept.departmentname
                }
                )
                .OrderBy(d => d.itemtypeid);
            bool any = source.Any();

            if (!any)
            {
                ItemTypeview.EmptyDataText = "No records found!!";
            }
            else
            {
                if (ItemTypeview != null)
                {
                    ItemTypeview.DataSource = source;
                    ItemTypeview.DataBind();
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (btnSubmit.Text == "Submit")
            {
                tblItemtype tblItemtyped = new tblItemtype

                {
                    departmentid = Convert.ToInt32(ddldepartment.SelectedItem.Value),
                    itemtype = txtitemTypeName.Text
                };
                objUnitOfWork.tblItemtypeRepository.Insert(tblItemtyped);
                if (objUnitOfWork.Save() > 0)
                {
                    GetItemtypedetails();
                    lblMsg.Text = "Records successfully inserted";
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
            else if (btnSubmit.Text == "Edit")
            {
                tblItemtype tblItemtyped = new tblItemtype();
                tblItemtyped = objUnitOfWork.tblItemtypeRepository.GetByID(itemtypeID);

                tblItemtyped.itemtype = txtitemTypeName.Text;
                tblItemtyped.departmentid = Convert.ToInt32(ddldepartment.SelectedItem.Value);



                objUnitOfWork.tblItemtypeRepository.Update(tblItemtyped);
                if (objUnitOfWork.Save() > 0)
                {
                    lblMsg.Text = "Records successfully inserted";
                    GetItemtypedetails();
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
            btnSubmit.Text = "Submit";
        }

        protected void lnkedit_Click(object sender, EventArgs e)
        {
            itemtypeID = int.Parse((((LinkButton)sender).CommandArgument).ToString());
            GridViewRow grdViewRow = (GridViewRow)((LinkButton)sender).Parent.Parent;
            txtitemTypeName.Text = grdViewRow.Cells[2].Text;
            ddldepartment.SelectedIndex = ddldepartment.Items.IndexOf(ddldepartment.Items.FindByValue(grdViewRow.Cells[2].Text));

            btnSubmit.Text = "Edit";
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            itemtypeID = int.Parse((((LinkButton)sender).CommandArgument).ToString());


            objUnitOfWork.tblbedtypeRepository.Delete(itemtypeID);
            if (objUnitOfWork.Save() > 0)
            {
                lblMsg.Text = "Records successfully removed";
                GetItemtypedetails();
            }
            else { lblMsg.Text = "Server Interrupted!!"; }

        }
    }
}