namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("TBLaccount")]
    public partial class TBLaccount
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public TBLaccount()
        {
            tbltheoreapylogs = new HashSet<tbltheoreapylog>();
            tbltherapydetails = new HashSet<tbltherapydetail>();
            tbltherapydetails1 = new HashSet<tbltherapydetail>();
            tbltherapydetails2 = new HashSet<tbltherapydetail>();
            tblappointments = new HashSet<tblappointment>();
            tblenquiries = new HashSet<tblenquiry>();
            TBLlogindetails = new HashSet<TBLlogindetail>();
            tblorders = new HashSet<tblorder>();
        }

        [Key]
        [StringLength(50)]
        public string loginID { get; set; }

        [StringLength(50)]
        public string name { get; set; }

        public int? designationid { get; set; }

        [StringLength(50)]
        public string password { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tbltheoreapylog> tbltheoreapylogs { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tbltherapydetail> tbltherapydetails { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tbltherapydetail> tbltherapydetails1 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tbltherapydetail> tbltherapydetails2 { get; set; }

        public virtual TBLdesignation TBLdesignation { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tblappointment> tblappointments { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tblenquiry> tblenquiries { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<TBLlogindetail> TBLlogindetails { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tblorder> tblorders { get; set; }
    }
}
