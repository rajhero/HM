namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class TBLdistributordetail
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public TBLdistributordetail()
        {
            tblorders = new HashSet<tblorder>();
        }

        [Key]
        public int distributorid { get; set; }

        [StringLength(250)]
        public string companyname { get; set; }

        [StringLength(250)]
        public string address { get; set; }

        [StringLength(150)]
        public string contactperson { get; set; }

        [StringLength(50)]
        public string pocmobile { get; set; }

        [StringLength(50)]
        public string companymobile { get; set; }

        [StringLength(50)]
        public string email { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tblorder> tblorders { get; set; }
    }
}
