namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("tblbed")]
    public partial class tblbed
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public tblbed()
        {
            tbladmitdetails = new HashSet<tbladmitdetail>();
        }

        [Key]
        public int bedid { get; set; }

        public int roomid { get; set; }

        public int? bedno { get; set; }

        [StringLength(50)]
        public string bedtype { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tbladmitdetail> tbladmitdetails { get; set; }

        public virtual tblroom tblroom { get; set; }
    }
}
