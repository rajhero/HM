﻿using HMS.DAL;
using HMS.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HMS.Receptionist
{
    public partial class FRMbill : System.Web.UI.Page
    {
        private UnitOfWork objUnitOfWork = new UnitOfWork();
        private ServiceModel objServiceModel = new ServiceModel();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ddlbillfor_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Txtpatientid_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Txtpatientid.Text))
            {
                var _appointment = objUnitOfWork.tblappointment.Get()
                         .Join(objServiceModel.TBLpatients, app => app.patientid, pat => pat.patientid, (app, pat) => new { app.patientid, app.appointmentid, pat.cardno, appointmentinfo = app.doctor + "|" + app.starttime + "-To-" + app.endtime })
                         .Where(d => d.cardno == Txtpatientid.Text).Select(d => new { appointmentid = d.appointmentid, appointmentinfo = d.appointmentinfo }).ToList();
                var admitdetail = objUnitOfWork.tbladmitdetailRepository.Get()
                           .Join(objServiceModel.tblbeds, adm => adm.bedid, bed => bed.bedid, (adm, bed) => new { adm.admitdetailsid, adm.bedid, adm.todate, adm.fromdate, adm.patientid, bed.roomid })
                           .Join(objServiceModel.tblrooms, adm => adm.roomid, room => room.roomid, (adm, room) => new { adm.admitdetailsid, adm.bedid, adm.todate, adm.fromdate, adm.patientid, room.roomid, room.roomno, room.roomtypeid })
                           .Join(objServiceModel.tblroomtypes, adm => adm.roomtypeid, roomtyp => roomtyp.roomtypeid, (adm, roomtyp) => new { adm.admitdetailsid, adm.bedid, adm.todate, adm.fromdate, adm.patientid, adm.roomid, adm.roomno, adm.roomtypeid, roomtyp.roomprice })
                           .Join(objServiceModel.TBLpatients, adm => adm.patientid, pat => pat.patientid, (adm, pat) => new { adm.admitdetailsid, adm.bedid, adm.todate, adm.fromdate, adm.patientid, adm.roomid, adm.roomno, adm.roomtypeid, adm.roomprice, pat.cardno }).Where(d => d.cardno == Txtpatientid.Text).Select(d => new { admitdetailsid = d.admitdetailsid, bedid = d.bedid, todate = d.todate, fromdate = d.fromdate, patientid = d.patientid, roomid = d.roomid, roomno = d.roomno, roomtypeid = d.roomtypeid, roomprice = d.roomprice, cardno = d.cardno }).ToList();
                var treatment = objUnitOfWork.tbltreatment.Get()
                     .Join(objServiceModel.tbltreatmentdetails, trt => trt.treatmentid, trd => trd.treamentid, (trt, trd) => new { trt.treatmentid, trt.patientid, trd.treatmentdetailsid })
                     .Join(objServiceModel.tbltreatmenttabletdetails, trt => trt.treatmentdetailsid, trd => trd.treatmentdetailsid, (trt, trd) => new { trt.treatmentid, trt.patientid, trd.treatmentdetailsid, trd.tabletid, trd.qty }).Join(objServiceModel.tblitems, trt => trt.tabletid, trd => trd.itemid, (trt, trd) => new { trt.treatmentid, trt.patientid, trt.treatmentdetailsid, trt.tabletid, trt.qty,trd.item }).Join(objServiceModel.TBLpatients, adm => adm.patientid, pat => pat.patientid, (adm, pat) => new
                     {
                         adm.treatmentid,
                         adm.patientid,
                         adm.treatmentdetailsid,
                         adm.tabletid,
                         adm.item,
                         adm.qty,
                         pat.cardno
                     })
                     .Where(d => d.cardno == Txtpatientid.Text).Select(adm => new
                     {
                         treatmentid = adm.treatmentid,
                         patientid = adm.patientid,
                         treatmentdetailsid = adm.treatmentdetailsid,
                         tabletid = adm.tabletid,
                         item = adm.item,
                         itemqty = adm.qty,
                         cardno = adm.cardno
                     }).ToList();

                DataTable dt = new DataTable();
                DataColumn dataColumn0 = new DataColumn("itemid", typeof(string));
                DataColumn dataColumn1 = new DataColumn("item", typeof(string));
                DataColumn dataColumn2 = new DataColumn("Quantity", typeof(string));
                DataColumn dataColumn3 = new DataColumn("Price", typeof(string));
                dt.Columns.Add(dataColumn0);
                dt.Columns.Add(dataColumn1);
                dt.Columns.Add(dataColumn2);
                dt.Columns.Add(dataColumn3);

                if (admitdetail != null && admitdetail.Any())
                {
                    for (int i = 0; i < admitdetail.Count(); i++)
                    {
                        DataRow dr = dt.NewRow();
                        dr["itemid"] = admitdetail[i].admitdetailsid;
                        dr["item"] = admitdetail[i].roomno + "|" + admitdetail[i].fromdate + "|" + admitdetail[i].todate;
                        dr["Quantity"] = admitdetail.Count();
                        dr["Price"] = admitdetail[i].roomprice;
                        dt.Rows.Add(dr);
                    }
                }
                if (_appointment != null && _appointment.Any())
                {
                    for (int i = 0; i < _appointment.Count(); i++)
                    {
                        DataRow dr = dt.NewRow();
                        dr["itemid"] = _appointment[i].appointmentid;
                        dr["item"] = _appointment[i].appointmentinfo;
                        dr["Quantity"] = _appointment.Count();
                        dr["Price"] = "0";
                        dt.Rows.Add(dr);
                    }
                }
                if (treatment != null && treatment.Any())
                {
                    for (int i = 0; i < treatment.Count(); i++)
                    {
                        DataRow dr = dt.NewRow();
                        dr["itemid"] = treatment[i].treatmentid;
                        dr["item"] = treatment[i].item;
                        dr["Quantity"] = treatment[i].itemqty;
                        dr["Price"] = "0";
                        dt.Rows.Add(dr);
                    }
                }


                if (dt.Rows.Count > 0)
                {
                    grdpatienttreatmentdetails.DataSource = dt;
                    grdpatienttreatmentdetails.DataBind();
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        //grdpatienttreatmentdetails.Rows[i].Cells[0].Text = dt.Rows[i]["itemid"].ToString();
                        TextBox txtItem = (TextBox)(grdpatienttreatmentdetails.Rows[i].Cells[1].FindControl("txtItem"));
                        txtItem.Text = dt.Rows[i]["item"].ToString();
                        TextBox txtqty = (TextBox)(grdpatienttreatmentdetails.Rows[i].Cells[2].FindControl("txtqty"));
                        txtqty.Text = dt.Rows[i]["Quantity"].ToString();
                        TextBox txtprice = (TextBox)(grdpatienttreatmentdetails.Rows[i].Cells[3].FindControl("txtprice"));
                        txtprice.Text = dt.Rows[i]["Price"].ToString();

                    }
                }


            }
        }

        protected void grdpatienttreatmentdetails_RowDataBound(object sender, GridViewRowEventArgs e)
        {

        }

        protected void grdpurchsedetail_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void grdPurchasedetail_RowDataBound(object sender, GridViewRowEventArgs e)
        {

        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            tblbill tblbill = new tblbill
            {
                billdate = DateTime.Now,
                discount = Convert.ToDecimal(txtdiscount.Text),
                total = Convert.ToDecimal(txttotal.Text)
                //taxpercent removed as taken evry individual item
                //add created by field

            };
            objUnitOfWork.tblbill.Insert(tblbill);
            if (objUnitOfWork.Save() > 0)
            {
                for (int i = 0; i < grdpatienttreatmentdetails.Rows.Count; i++)
                {
                    int Itemid = Convert.ToInt32(grdpatienttreatmentdetails.Rows[i].Cells[0].Text);
                    TextBox txtqty = (TextBox)(grdpatienttreatmentdetails.Rows[i].Cells[2].FindControl("txtqty"));
                    TextBox txtprice = (TextBox)(grdpatienttreatmentdetails.Rows[i].Cells[3].FindControl("txtprice"));
                    TextBox txtSGST = (TextBox)(grdpatienttreatmentdetails.Rows[i].Cells[3].FindControl("txtSGST"));
                    TextBox txtCGST = (TextBox)(grdpatienttreatmentdetails.Rows[i].Cells[3].FindControl("txtCGST"));

                    tblBilldetail tblBilldetail = new tblBilldetail
                    {
                        //grdpatienttreatmentdetails.Rows[i].Cells[0].Text = dt.Rows[i]["itemid"].ToString();

                        item = Itemid,

                        qty = Convert.ToInt32(txtqty.Text),
                        
                        price = Convert.ToDecimal(txtprice.Text),
                        cgst = Convert.ToDecimal(txtCGST.Text),
                        sgst = Convert.ToDecimal(txtSGST.Text)
                    };
                    objUnitOfWork.tblBillDetailsRepository.Insert(tblBilldetail);
                    if (objUnitOfWork.Save() > 0)
                    {
                    }
                    else { }

                }
            }
            else { }


        }

        protected void btnprint_Click(object sender, EventArgs e)
        {

        }
    }
}