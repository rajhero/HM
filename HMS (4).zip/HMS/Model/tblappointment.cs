namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("tblappointment")]
    public partial class tblappointment
    {
        [Key]
        public int appointmentid { get; set; }

        public int patientid { get; set; }

        public DateTime? starttime { get; set; }

        public DateTime? endtime { get; set; }

        [StringLength(50)]
        public string doctor { get; set; }

        [StringLength(50)]
        public string location { get; set; }

        [StringLength(50)]
        public string entrydate { get; set; }

        [StringLength(50)]
        public string entryby { get; set; }

        public virtual TBLaccount TBLaccount { get; set; }

        public virtual TBLpatient TBLpatient { get; set; }
    }
}
