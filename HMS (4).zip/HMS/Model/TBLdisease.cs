namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("TBLdisease")]
    public partial class TBLdisease
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public TBLdisease()
        {
            tbltreatmentdetails = new HashSet<tbltreatmentdetail>();
        }

        [Key]
        public int diseaseid { get; set; }

        public string disease { get; set; }

        public string description { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tbltreatmentdetail> tbltreatmentdetails { get; set; }
    }
}
