﻿using HMS.DAL;
using HMS.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HMS.Admin
{
    public partial class Frmroomtype : System.Web.UI.Page
    {

        private static int _roomtypeID;

        public static int RoomtypeID { get => _roomtypeID; set => _roomtypeID = value; }
        private UnitOfWork objUnitOfWork = new UnitOfWork();
        private ServiceModel objServiceModel = new ServiceModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["controllerID"] != null)
            {
                if (!this.IsPostBack)
                {
                    Getroomtypedetails(); Clear();
                }
            }
        }

        private void Clear() { txtRoomTypeName.Text=txtroomdiscription.Text=txtroomprice.Text = string.Empty; }

        private void Getroomtypedetails()
        {
            var source = objUnitOfWork.tblroomtypeRepository.Get().OrderBy(d => d.roomtype);
            bool any = source.Any();

            if (!any)
            {
                Roomtypeview.EmptyDataText = "No records found!!";
            }
            else
            {
                if (Roomtypeview != null)
                {
                    Roomtypeview.DataSource = source;
                    Roomtypeview.DataBind();
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (btnSubmit.Text == "Submit")
            {
                tblroomtype tblroomtype = new tblroomtype
                {
                    roomtype = txtRoomTypeName.Text,
                    roomprice = txtroomprice.Text,
                    roomdiscription = txtroomdiscription.Text,

                };
                objUnitOfWork.tblroomtypeRepository.Insert(tblroomtype);
                if (objUnitOfWork.Save() > 0)
                {
                    Getroomtypedetails();
                    lblMsg.Text = "Records successfully inserted";
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
            else if (btnSubmit.Text == "Edit")
            {
                tblroomtype tblroomtype = new tblroomtype();
                tblroomtype = objUnitOfWork.tblroomtypeRepository.GetByID(RoomtypeID);
                tblroomtype.roomtype = txtRoomTypeName.Text;
                tblroomtype.roomprice = txtroomprice.Text;
                tblroomtype.roomdiscription = txtroomdiscription.Text;
                
                objUnitOfWork.tblroomtypeRepository.Update(tblroomtype);
                if (objUnitOfWork.Save() > 0)
                {
                    lblMsg.Text = "Records successfully inserted";
                    Getroomtypedetails();
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
            btnSubmit.Text = "Submit";
        }

        protected void lnkedit_Click(object sender, EventArgs e)
        {
            RoomtypeID = int.Parse((((LinkButton)sender).CommandArgument).ToString());
            GridViewRow grdViewRow = (GridViewRow)((LinkButton)sender).Parent.Parent;
            txtRoomTypeName.Text = grdViewRow.Cells[1].Text;
            txtroomprice.Text = grdViewRow.Cells[2].Text;
            txtroomdiscription.Text = grdViewRow.Cells[3].Text;
            btnSubmit.Text = "Edit";
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            RoomtypeID = int.Parse((((LinkButton)sender).CommandArgument).ToString());


            objUnitOfWork.tblroomtypeRepository.Delete(RoomtypeID);
            if (objUnitOfWork.Save() > 0)
            {
                lblMsg.Text = "Records successfully removed";
                Getroomtypedetails();
            }
            else { lblMsg.Text = "Server Interrupted!!"; }

        }
    }
}