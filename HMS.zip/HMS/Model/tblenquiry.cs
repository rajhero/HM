namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("tblenquiry")]
    public partial class tblenquiry
    {
        [Key]
        public int enquiryid { get; set; }

        public string name { get; set; }

        public string address { get; set; }

        [StringLength(50)]
        public string mobile { get; set; }

        [StringLength(150)]
        public string email { get; set; }

        [StringLength(250)]
        public string occupation { get; set; }

        public string reason { get; set; }

        [StringLength(150)]
        public string leadby { get; set; }

        [StringLength(50)]
        public string leadcontact { get; set; }

        [StringLength(250)]
        public string leadaddress { get; set; }

        [StringLength(50)]
        public string userid { get; set; }

        public virtual TBLaccount TBLaccount { get; set; }
    }
}
