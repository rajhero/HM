namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class TBLlogindetail
    {
        [Key]
        public int logindetailsid { get; set; }

        [StringLength(50)]
        public string loginid { get; set; }

        [StringLength(50)]
        public string loginintime { get; set; }

        [StringLength(50)]
        public string loginouttime { get; set; }

        public virtual TBLaccount TBLaccount { get; set; }
    }
}
