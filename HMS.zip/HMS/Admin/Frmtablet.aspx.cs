﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HMS.DAL;
using HMS.Model;
namespace HMS.Admin
{
    public partial class Frmtablet : System.Web.UI.Page
    {

        private static int _tabletID;

        public static int TabletID { get => _tabletID; set => _tabletID = value; }
        private UnitOfWork objUnitOfWork = new UnitOfWork();
        private ServiceModel objServiceModel = new ServiceModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["controllerID"] != null)
            {
                if (!this.IsPostBack)
                {
                    GetTabletdetails(); Clear();
                }
            }
        }

        private void Clear() => txtTabletName.Text = string.Empty;

        private void GetTabletdetails()
        {
            var tablet=objUnitOfWork.TbldiseaseRepository.Get().OrderBy(d => d.diseaseid);
            bool any = tablet.Any();

            if (!any)
            {
                Tabletview.EmptyDataText = "No records found!!";
            }
            else
            {
                if (Tabletview != null)
                {
                    Tabletview.DataSource = tablet;
                    Tabletview.DataBind();
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (btnSubmit.Text == "Submit")
            {
                TBLtablet TBLtablet = new TBLtablet
                { 
                    tablet = txtTabletName.Text
                };
                objUnitOfWork.TbltabletRepository.Insert(TBLtablet);
                if (objUnitOfWork.Save() > 0)
                {
                    GetTabletdetails();
                    lblMsg.Text = "Records successfully inserted";
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
            else if (btnSubmit.Text == "Edit")
            {
                TBLtablet TBLtablet = new TBLtablet();
                TBLtablet = objUnitOfWork.TbltabletRepository.GetByID(TabletID);
                TBLtablet.tablet = txtTabletName.Text;
                objUnitOfWork.TbltabletRepository.Update(TBLtablet);
                if (objUnitOfWork.Save() > 0)
                {
                    lblMsg.Text = "Records successfully inserted";
                    GetTabletdetails();
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
            btnSubmit.Text = "Submit";
        }

        protected void lnkedit_Click(object sender, EventArgs e)
        {
            TabletID = int.Parse((((LinkButton)sender).CommandArgument).ToString());
            GridViewRow grdViewRow = (GridViewRow)((LinkButton)sender).Parent.Parent;
            txtTabletName.Text = grdViewRow.Cells[0].Text;
            btnSubmit.Text = "Edit";
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            TabletID = int.Parse((((LinkButton)sender).CommandArgument).ToString());
             

            objUnitOfWork.TbltabletRepository.Delete(TabletID);
            if (objUnitOfWork.Save() > 0)
            {
                lblMsg.Text = "Records successfully removed";
                GetTabletdetails();
            }
            else { lblMsg.Text = "Server Interrupted!!"; }

        }
    }
}