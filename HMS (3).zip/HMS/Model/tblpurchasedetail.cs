namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class tblpurchasedetail
    {
        [Key]
        public int purchasedetailsid { get; set; }

        public int purchaseid { get; set; }

        public int tablet { get; set; }

        public int qty { get; set; }

        public decimal rate { get; set; }

        [StringLength(50)]
        public string type { get; set; }

        public DateTime? expdate { get; set; }

        public DateTime? manufacturedate { get; set; }

        [StringLength(50)]
        public string batchno { get; set; }

        public virtual tblpurchase tblpurchase { get; set; }
    }
}
