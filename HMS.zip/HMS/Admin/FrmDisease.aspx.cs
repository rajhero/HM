﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HMS.DAL;
using HMS.Model;

namespace HMS.Admin
{
    public partial class FrmDisease : System.Web.UI.Page
    {

        private static int _diseaseID;

        public static int DiseaseID { get { return _diseaseID; } set { _diseaseID = value; } }
        private UnitOfWork objUnitOfWork = new UnitOfWork();
        private ServiceModel objServiceModel = new ServiceModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["controllerID"] != null)
            {
                if (!this.IsPostBack)
                {
                    GetDiseasedetails(); Clear();
                }
            }
        }

        private void Clear() => txtdiseaseName.Text = string.Empty;

        private void GetDiseasedetails()
        {
            var source = objUnitOfWork.TbldiseaseRepository.Get().OrderBy(d => d.diseaseid);
            if (source.Count() > 0)
            {
                diseaseview.DataSource = source;
                diseaseview.DataBind();
            }
            else
            {
                diseaseview.EmptyDataText = "No records found!!";
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (btnSubmit.Text == "Submit")
            {
                TBLdisease tblDisease = new TBLdisease
                {
                    disease = txtdiseaseName.Text
                };
                objUnitOfWork.TbldiseaseRepository.Insert(tblDisease);
                if (objUnitOfWork.Save() > 0)
                {

                    lblMsg.Text = "Records successfully inserted";
                    GetDiseasedetails();
                    Clear();
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
            else if (btnSubmit.Text == "Edit")
            {
                TBLdisease tblDisease = new TBLdisease();
                tblDisease = objUnitOfWork.TbldiseaseRepository.GetByID(_diseaseID);
                tblDisease.disease = txtdiseaseName.Text;
                objUnitOfWork.TbldiseaseRepository.Update(tblDisease);
                if (objUnitOfWork.Save() > 0)
                {
                    lblMsg.Text = "Records successfully Updated";
                    GetDiseasedetails();
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
            btnSubmit.Text = "Submit";
        }

        protected void lnkedit_Click(object sender, EventArgs e)
        {
            _diseaseID = int.Parse((((LinkButton)sender).CommandArgument).ToString());
            GridViewRow grdViewRow = (GridViewRow)((LinkButton)sender).Parent.Parent;
            txtdiseaseName.Text = grdViewRow.Cells[0].Text;
            btnSubmit.Text = "Edit";
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            _diseaseID = int.Parse((((LinkButton)sender).CommandArgument).ToString());
            TBLdisease tblDisease = new TBLdisease();

            objUnitOfWork.TbldiseaseRepository.Delete(_diseaseID);
            objUnitOfWork.Save();

        }
    }
}