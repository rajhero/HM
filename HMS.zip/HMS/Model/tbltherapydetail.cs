namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class tbltherapydetail
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public tbltherapydetail()
        {
            tbltheoreapylogs = new HashSet<tbltheoreapylog>();
        }

        [Key]
        public int therapydetailsid { get; set; }

        public int treatementid { get; set; }

        [Required]
        [StringLength(50)]
        public string caretaker { get; set; }

        [Required]
        [StringLength(50)]
        public string supervior { get; set; }

        public int treatmenttypeid { get; set; }

        [StringLength(50)]
        public string fromdate { get; set; }

        [StringLength(50)]
        public string todate { get; set; }

        [StringLength(50)]
        public string entrydate { get; set; }

        [Required]
        [StringLength(50)]
        public string entryby { get; set; }

        public virtual TBLaccount TBLaccount { get; set; }

        public virtual TBLaccount TBLaccount1 { get; set; }

        public virtual TBLaccount TBLaccount2 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tbltheoreapylog> tbltheoreapylogs { get; set; }

        public virtual tbltreatment tbltreatment { get; set; }

        public virtual tbltreatementtype tbltreatementtype { get; set; }
    }
}
