namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("tblitem")]
    public partial class tblitem
    {
        public tblitem()
        {
            tblorderdetails = new HashSet<tblorderdetail>();
            tbltreatmenttabletdetails = new HashSet<tbltreatmenttabletdetail>();
        }
        [Key]
        public int itemid { get; set; }

        public int? itemtypeid { get; set; }

        public string item { get; set; }

        public string itemdescription { get; set; }

        public virtual tblItemtype tblItemtype { get; set; }
        public virtual ICollection<tblorderdetail> tblorderdetails { get; set; }
        public virtual ICollection<tbltreatmenttabletdetail> tbltreatmenttabletdetails { get; set; }

    }
}
