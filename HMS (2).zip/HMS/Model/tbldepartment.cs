namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("tbldepartment")]
    public partial class tbldepartment
    {
        [Key]
        public int departmentID { get; set; }

        [StringLength(50)]
        public string departmentname { get; set; }
    }
}
