namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class tbltreatmenttabletdetail
    {
        [Key]
        public int treatmenttabletid { get; set; }

        public int treatmentdetailsid { get; set; }

        public int tabletid { get; set; }

        public int? qty { get; set; }

        [StringLength(150)]
        public string dosagedetails { get; set; }

        public virtual tbltreatmentdetail tbltreatmentdetail { get; set; }
    }
}
