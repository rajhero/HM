namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("TBLpatient")]
    public partial class TBLpatient
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public TBLpatient()
        {
            tbladmitdetails = new HashSet<tbladmitdetail>();
            tblappointments = new HashSet<tblappointment>();
            tbltherapydetails = new HashSet<tbltherapydetail>();
            tbltreatments = new HashSet<tbltreatment>();
        }

        [Key]
        public int patientid { get; set; }

        public string name { get; set; }

        [StringLength(50)]
        public string mobile { get; set; }

        [StringLength(50)]
        public string email { get; set; }

        public string address { get; set; }

        [StringLength(50)]
        public string occupation { get; set; }

        [StringLength(50)]
        public string cardno { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tbladmitdetail> tbladmitdetails { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tblappointment> tblappointments { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tbltherapydetail> tbltherapydetails { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tbltreatment> tbltreatments { get; set; }
    }
}
