namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class tblorderdetail
    {
        [Key]
        public int orderdetailsid { get; set; }

        public int orderid { get; set; }

        public int tablet { get; set; }

        public int qty { get; set; }

        public virtual tblitem tblitem { get; set; }

        public virtual tblorder tblorder { get; set; }
    }
}
