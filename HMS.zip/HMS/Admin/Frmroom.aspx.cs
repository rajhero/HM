﻿using HMS.DAL;
using HMS.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HMS.Admin
{
    public partial class Frmroom : System.Web.UI.Page
    {

        private static int _roomID;

        public static int roomID { get => _roomID; set => _roomID = value; }
        private UnitOfWork objUnitOfWork = new UnitOfWork();
        private ServiceModel objServiceModel = new ServiceModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["controllerID"] != null)
            {
                if (!this.IsPostBack)
                {
                    Getroomdetails(); Clear();
                }
            }
        }

        private void Clear() { txtroomlocation.Text = txtroomno.Text = string.Empty; ddlroomtype.SelectedIndex = 0; }

        private void Getroomdetails()
        {
            var source = objUnitOfWork.tblroomRepository.Get().
                  Join(objServiceModel.tblroomtypes,
                    ac => ac.roomtypeid,
                    de => de.roomtypeid,
                    (ac, de) =>
                        new
                        {
                            roomid = ac.roomid,
                            roomno = ac.roomno,
                            roomlocation = ac.roomlocation,
                            roomtypeid = ac.roomtypeid
                        }).OrderBy(d => d.roomno);
            bool any = source.Any();

            if (!any)
            {
                roomview.EmptyDataText = "No records found!!";
            }
            else
            {
                if (roomview != null)
                {
                    roomview.DataSource = source;
                    roomview.DataBind();
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (btnSubmit.Text == "Submit")
            {
                tblroom tblroom = new tblroom
                {
                    roomlocation= txtroomlocation.Text,
                    roomno = Convert.ToInt32(txtroomno.Text),
                    roomtypeid = Convert.ToInt32(ddlroomtype.SelectedItem.Value),
                };
                objUnitOfWork.tblroomRepository.Insert(tblroom);
                if (objUnitOfWork.Save() > 0)
                {
                    Getroomdetails();
                    lblMsg.Text = "Records successfully inserted";
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
            else if (btnSubmit.Text == "Edit")
            {
                tblroom tblroom = new tblroom();
                tblroom = objUnitOfWork.tblroomRepository.GetByID(roomID);
                tblroom.roomtypeid = Convert.ToInt32( ddlroomtype.SelectedItem.Value);
                tblroom.roomno = Convert.ToInt32(txtroomno.Text);
                tblroom.roomlocation= txtroomlocation.Text;
                objUnitOfWork.tblroomRepository.Update(tblroom);
                if (objUnitOfWork.Save() > 0)
                {
                    lblMsg.Text = "Records successfully inserted";
                    Getroomdetails();
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
            btnSubmit.Text = "Submit";
        }

        protected void lnkedit_Click(object sender, EventArgs e)
        {
            roomID = int.Parse((((LinkButton)sender).CommandArgument).ToString());
            GridViewRow grdViewRow = (GridViewRow)((LinkButton)sender).Parent.Parent;
            txtroomno.Text = grdViewRow.Cells[1].Text;
            ddlroomtype.SelectedIndex = ddlroomtype.Items.IndexOf(ddlroomtype.Items.FindByValue(grdViewRow.Cells[4].Text));
            txtroomlocation.Text = grdViewRow.Cells[2].Text;
           
            btnSubmit.Text = "Edit";
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            roomID = int.Parse((((LinkButton)sender).CommandArgument).ToString());


            objUnitOfWork.tblroomRepository.Delete(roomID);
            if (objUnitOfWork.Save() > 0)
            {
                lblMsg.Text = "Records successfully removed";
                Getroomdetails();
            }
            else { lblMsg.Text = "Server Interrupted!!"; }

        }
    }
}