namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("tblItemtype")]
    public partial class tblItemtype
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public tblItemtype()
        {
            tblitems = new HashSet<tblitem>();
        }

        [Key]
        public int itemtypeid { get; set; }

        [StringLength(50)]
        public string itemtype { get; set; }

        public int? departmentid { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tblitem> tblitems { get; set; }
    }
}
