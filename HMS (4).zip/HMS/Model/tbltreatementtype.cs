namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("tbltreatementtype")]
    public partial class tbltreatementtype
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public tbltreatementtype()
        {
            tbltherapydetails = new HashSet<tbltherapydetail>();
        }

        [Key]
        public int treatmenttypeid { get; set; }

        [StringLength(50)]
        public string treatmenttype { get; set; }

        public string treatmentdescription { get; set; }

        public int? treatmentdays { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tbltherapydetail> tbltherapydetails { get; set; }
    }
}
