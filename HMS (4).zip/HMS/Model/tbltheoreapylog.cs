namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("tbltheoreapylog")]
    public partial class tbltheoreapylog
    {
        [Key]
        public int theoreapylogid { get; set; }

        public int therapydetailsid { get; set; }

        [StringLength(50)]
        public string entrydate { get; set; }

        [Required]
        [StringLength(50)]
        public string entryby { get; set; }

        public string comment { get; set; }

        public string feedback { get; set; }

        public virtual TBLaccount TBLaccount { get; set; }

        public virtual tbltherapydetail tbltherapydetail { get; set; }
    }
}
