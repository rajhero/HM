﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HMS.Model;
using HMS.DAL;
 

namespace HMS
{
    public partial class Default : System.Web.UI.Page
    {
         
         
        /// <inheritdoc />
        public enum Cases:int
        {
           [StringValue("~/Admin/AdminHome.aspx") ] admin=1,
            [StringValue("~/Receptionist/Home.aspx")] receptionist = 2,
            [StringValue("~/Admin/AdminHome.aspx")] doctor = 3,
            [StringValue("~/Admin/AdminHome.aspx")] superadmin = 4

        }

        private UnitOfWork objUnitOfWork = new UnitOfWork();
        private ServiceModel objServiceModel = new ServiceModel();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Clear(); 
            }
        }

        public void Clear() => Txtusername.Text = TxtPassword.Text = string.Empty;

        public Cases obj = Cases.admin;
        protected void BtnLogin_Click(object sender, EventArgs e)
        {

            var _desig = objUnitOfWork.TblaccountRepository.Get().Join(objServiceModel.TBLdesignations, acc => acc.designationid, desig => desig.DesignationID
                    , (acc, desig) => new { Designation = desig.Designation, loginID = acc.loginID, password = acc.password, name = acc.name, designationid = acc.designationid }).Where(d=>d.loginID== Txtusername.Text & d.password== TxtPassword.Text).ToList();

            if (_desig != null && _desig.Count()>0)
            {
                //if (TbLaccount.password != null && TbLaccount.loginID != null &&
                //      string.Equals(TbLaccount.loginID, Txtusername.Text, StringComparison.InvariantCulture) && string.Equals(
                //          a: TbLaccount.password, b: TxtPassword.Text,
                //          comparisonType: StringComparison.InvariantCulture))
                //{
                Cases obj;
                Enum.TryParse<Cases>(_desig[0].Designation.ToLower(), out obj);
                    switch (obj)
                    {
                        case Cases.admin:
                            Session["controllerID"] = Txtusername.Text;
                            Response.Redirect(StringValueAttribute.GetStringValue(Cases.admin));

                            break;
                        case Cases.doctor:
                            Session["controllerID"] = Txtusername.Text;
                            Response.Redirect(StringValueAttribute.GetStringValue(Cases.doctor));
                            break;
                        case Cases.receptionist:
                            Session["controllerID"] = Txtusername.Text;
                            Response.Redirect(StringValueAttribute.GetStringValue(Cases.receptionist));
                            break;
                        case Cases.superadmin:
                            Session["controllerID"] = Txtusername.Text;
                            Response.Redirect(StringValueAttribute.GetStringValue(Cases.superadmin));
                            break;

                    }

                
            }
            else {
                Response.Write("No User");
            }
        }
    }
}