﻿using HMS.DAL;
using HMS.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HMS.Admin
{
    public partial class Frmbedtype : System.Web.UI.Page
    {

        private static int _bedtypeID;

        public static int bedtypeID
        {
            get { return _bedtypeID; }
            set { _bedtypeID = value; }
        }
        private UnitOfWork objUnitOfWork = new UnitOfWork();
        private ServiceModel objServiceModel = new ServiceModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["controllerID"] != null)
            {
                if (!this.IsPostBack)
                {
                    Getbedtypedetails(); Clear();
                }
            }
        }

        private void Clear() => txtBedTypeName.Text = string.Empty;

        private void Getbedtypedetails(int id=0)
        {
            if (id == 0)
            {
                var source = objUnitOfWork.tblbedtypeRepository.Get().OrderBy(d => d.bedtypeid);
                bool any = source.Any();

                if (!any)
                {
                    BedTypeview.EmptyDataText = "No records found!!";
                }
                else
                {
                    if (BedTypeview != null)
                    {
                        BedTypeview.DataSource = source;
                        BedTypeview.DataBind();
                    }
                }
            }
            else {
                var source = objUnitOfWork.tblbedtypeRepository.Get().Where(d=>d.bedtypeid==id).OrderBy(d => d.bedtypeid);
                bool any = source.Any();

                if (!any)
                {
                    GridView1.EmptyDataText = "No records found!!";
                }
                else
                {
                    if (GridView1 != null)
                    {
                        GridView1.DataSource = source;
                        GridView1.DataBind();
                    }
                }

            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (btnSubmit.Text == "Submit")
            {
                tblbedtype tblbedtype = new tblbedtype
                {
                    bedtype = txtBedTypeName.Text
                };
                objUnitOfWork.tblbedtypeRepository.Insert(tblbedtype);
                if (objUnitOfWork.Save() > 0)
                {
                    Getbedtypedetails(tblbedtype.bedtypeid);
                    Clear();
                    lblMsg.Text = "Records successfully inserted";
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
            else if (btnSubmit.Text == "Edit")
            {
                tblbedtype tblbedtype = new tblbedtype();
                tblbedtype = objUnitOfWork.tblbedtypeRepository.GetByID(bedtypeID);
                tblbedtype.bedtype = txtBedTypeName.Text;
                objUnitOfWork.tblbedtypeRepository.Update(tblbedtype);
                if (objUnitOfWork.Save() > 0)
                {
                    lblMsg.Text = "Records successfully inserted";
                    Getbedtypedetails(tblbedtype.bedtypeid);
                    Clear();
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
            btnSubmit.Text = "Submit";
        }

        protected void lnkedit_Click(object sender, EventArgs e)
        {
            bedtypeID = int.Parse((((LinkButton)sender).CommandArgument).ToString());
            GridViewRow grdViewRow = (GridViewRow)((LinkButton)sender).Parent.Parent;
            txtBedTypeName.Text = grdViewRow.Cells[1].Text;
            btnSubmit.Text = "Edit";
            MultiView1.SetActiveView(AddView);
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            bedtypeID = int.Parse((((LinkButton)sender).CommandArgument).ToString());


            objUnitOfWork.tblbedtypeRepository.Delete(bedtypeID);
            if (objUnitOfWork.Save() > 0)
            {
                lblMsg.Text = "Records successfully removed";
                Getbedtypedetails();
            }
            else { lblMsg.Text = "Server Interrupted!!"; }

        }

        protected void btnaddview_Click(object sender, EventArgs e)
        {
            Clear();
            MultiView1.SetActiveView(AddView);
        }

        protected void btndisplay_Click(object sender, EventArgs e)
        {
            Getbedtypedetails();
            MultiView1.SetActiveView(displayView);
        }
    }
}