namespace HMS.models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class Models : DbContext
    {
        public Models()
            : base("name=Models")
        {
        }

        public virtual DbSet<TBLaccount> TBLaccounts { get; set; }
        public virtual DbSet<tbladmitdetail> tbladmitdetails { get; set; }
        public virtual DbSet<tblappointment> tblappointments { get; set; }
        public virtual DbSet<tblattribute> tblattributes { get; set; }
        public virtual DbSet<tblbed> tblbeds { get; set; }
        public virtual DbSet<tblbedtype> tblbedtypes { get; set; }
        public virtual DbSet<tblbill> tblbills { get; set; }
        public virtual DbSet<tblBilldetail> tblBilldetails { get; set; }
        public virtual DbSet<tbldepartment> tbldepartments { get; set; }
        public virtual DbSet<TBLdesignation> TBLdesignations { get; set; }
        public virtual DbSet<TBLdisease> TBLdiseases { get; set; }
        public virtual DbSet<TBLdistributordetail> TBLdistributordetails { get; set; }
        public virtual DbSet<tblenquiry> tblenquiries { get; set; }
        public virtual DbSet<tblitem> tblitems { get; set; }
        public virtual DbSet<tblItemtype> tblItemtypes { get; set; }
        public virtual DbSet<TBLlogindetail> TBLlogindetails { get; set; }
        public virtual DbSet<tblorder> tblorders { get; set; }
        public virtual DbSet<tblorderdetail> tblorderdetails { get; set; }
        public virtual DbSet<TBLpatient> TBLpatients { get; set; }
        public virtual DbSet<tblpurchase> tblpurchases { get; set; }
        public virtual DbSet<tblpurchasedetail> tblpurchasedetails { get; set; }
        public virtual DbSet<tblroom> tblrooms { get; set; }
        public virtual DbSet<tblroomtype> tblroomtypes { get; set; }
        public virtual DbSet<tbltheoreapylog> tbltheoreapylogs { get; set; }
        public virtual DbSet<tbltherapydetail> tbltherapydetails { get; set; }
        public virtual DbSet<tbltreatementtype> tbltreatementtypes { get; set; }
        public virtual DbSet<tbltreatment> tbltreatments { get; set; }
        public virtual DbSet<tbltreatmentdetail> tbltreatmentdetails { get; set; }
        public virtual DbSet<tbltreatmenttabletdetail> tbltreatmenttabletdetails { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<TBLaccount>()
                .Property(e => e.loginID)
                .IsUnicode(false);

            modelBuilder.Entity<TBLaccount>()
                .Property(e => e.name)
                .IsUnicode(false);

            modelBuilder.Entity<TBLaccount>()
                .Property(e => e.password)
                .IsUnicode(false);

            modelBuilder.Entity<TBLaccount>()
                .HasMany(e => e.tbltheoreapylogs)
                .WithRequired(e => e.TBLaccount)
                .HasForeignKey(e => e.entryby)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<TBLaccount>()
                .HasMany(e => e.tbltherapydetails)
                .WithRequired(e => e.TBLaccount)
                .HasForeignKey(e => e.caretaker)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<TBLaccount>()
                .HasMany(e => e.tbltherapydetails1)
                .WithRequired(e => e.TBLaccount1)
                .HasForeignKey(e => e.entryby)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<TBLaccount>()
                .HasMany(e => e.tbltherapydetails2)
                .WithRequired(e => e.TBLaccount2)
                .HasForeignKey(e => e.supervior)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<TBLaccount>()
                .HasMany(e => e.tblappointments)
                .WithOptional(e => e.TBLaccount)
                .HasForeignKey(e => e.doctor);

            modelBuilder.Entity<TBLaccount>()
                .HasMany(e => e.tblenquiries)
                .WithOptional(e => e.TBLaccount)
                .HasForeignKey(e => e.userid);

            modelBuilder.Entity<TBLaccount>()
                .HasMany(e => e.tblorders)
                .WithOptional(e => e.TBLaccount)
                .HasForeignKey(e => e.receiverid);

            modelBuilder.Entity<tbladmitdetail>()
                .Property(e => e.datetime)
                .IsUnicode(false);

            modelBuilder.Entity<tbladmitdetail>()
                .Property(e => e.status)
                .IsUnicode(false);

            modelBuilder.Entity<tbladmitdetail>()
                .Property(e => e.fromdate)
                .IsUnicode(false);

            modelBuilder.Entity<tbladmitdetail>()
                .Property(e => e.todate)
                .IsUnicode(false);

            modelBuilder.Entity<tbladmitdetail>()
                .Property(e => e.entrydate)
                .IsUnicode(false);

            modelBuilder.Entity<tbladmitdetail>()
                .Property(e => e.entryby)
                .IsUnicode(false);

            modelBuilder.Entity<tblappointment>()
                .Property(e => e.doctor)
                .IsUnicode(false);

            modelBuilder.Entity<tblappointment>()
                .Property(e => e.location)
                .IsUnicode(false);

            modelBuilder.Entity<tblappointment>()
                .Property(e => e.entrydate)
                .IsUnicode(false);

            modelBuilder.Entity<tblappointment>()
                .Property(e => e.entryby)
                .IsUnicode(false);

            modelBuilder.Entity<tblattribute>()
                .Property(e => e.attribute)
                .IsUnicode(false);

            modelBuilder.Entity<tblbed>()
                .Property(e => e.bedtype)
                .IsUnicode(false);

            modelBuilder.Entity<tblbedtype>()
                .Property(e => e.bedtype)
                .IsUnicode(false);

            modelBuilder.Entity<tblbill>()
                .Property(e => e.taxpercent)
                .HasPrecision(18, 0);

            modelBuilder.Entity<tblbill>()
                .Property(e => e.total)
                .HasPrecision(18, 0);

            modelBuilder.Entity<tblbill>()
                .Property(e => e.discount)
                .HasPrecision(18, 0);

            modelBuilder.Entity<tblBilldetail>()
                .Property(e => e.price)
                .HasPrecision(18, 0);

            modelBuilder.Entity<tblBilldetail>()
                .Property(e => e.cgst)
                .HasPrecision(18, 0);

            modelBuilder.Entity<tblBilldetail>()
                .Property(e => e.sgst)
                .HasPrecision(18, 0);

            modelBuilder.Entity<tbldepartment>()
                .Property(e => e.departmentname)
                .IsUnicode(false);

            modelBuilder.Entity<TBLdesignation>()
                .Property(e => e.Designation)
                .IsUnicode(false);

            modelBuilder.Entity<TBLdisease>()
                .Property(e => e.disease)
                .IsUnicode(false);

            modelBuilder.Entity<TBLdisease>()
                .Property(e => e.description)
                .IsUnicode(false);

            modelBuilder.Entity<TBLdisease>()
                .HasMany(e => e.tbltreatmentdetails)
                .WithRequired(e => e.TBLdisease)
                .HasForeignKey(e => e.deseaseid)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<TBLdistributordetail>()
                .Property(e => e.companyname)
                .IsUnicode(false);

            modelBuilder.Entity<TBLdistributordetail>()
                .Property(e => e.address)
                .IsUnicode(false);

            modelBuilder.Entity<TBLdistributordetail>()
                .Property(e => e.contactperson)
                .IsUnicode(false);

            modelBuilder.Entity<TBLdistributordetail>()
                .Property(e => e.pocmobile)
                .IsUnicode(false);

            modelBuilder.Entity<TBLdistributordetail>()
                .Property(e => e.companymobile)
                .IsUnicode(false);

            modelBuilder.Entity<TBLdistributordetail>()
                .Property(e => e.email)
                .IsUnicode(false);

            modelBuilder.Entity<TBLdistributordetail>()
                .HasMany(e => e.tblorders)
                .WithRequired(e => e.TBLdistributordetail)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<tblenquiry>()
                .Property(e => e.name)
                .IsUnicode(false);

            modelBuilder.Entity<tblenquiry>()
                .Property(e => e.address)
                .IsUnicode(false);

            modelBuilder.Entity<tblenquiry>()
                .Property(e => e.mobile)
                .IsUnicode(false);

            modelBuilder.Entity<tblenquiry>()
                .Property(e => e.email)
                .IsUnicode(false);

            modelBuilder.Entity<tblenquiry>()
                .Property(e => e.occupation)
                .IsUnicode(false);

            modelBuilder.Entity<tblenquiry>()
                .Property(e => e.reason)
                .IsUnicode(false);

            modelBuilder.Entity<tblenquiry>()
                .Property(e => e.leadby)
                .IsUnicode(false);

            modelBuilder.Entity<tblenquiry>()
                .Property(e => e.leadcontact)
                .IsUnicode(false);

            modelBuilder.Entity<tblenquiry>()
                .Property(e => e.leadaddress)
                .IsUnicode(false);

            modelBuilder.Entity<tblenquiry>()
                .Property(e => e.userid)
                .IsUnicode(false);

            modelBuilder.Entity<tblitem>()
                .Property(e => e.itemdescription)
                .IsUnicode(false);

            modelBuilder.Entity<tblitem>()
                .Property(e => e.item)
                .IsUnicode(false);

            modelBuilder.Entity<tblitem>()
                .HasMany(e => e.tblorderdetails)
                .WithRequired(e => e.tblitem)
                .HasForeignKey(e => e.tablet)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<tblItemtype>()
                .Property(e => e.itemtype)
                .IsUnicode(false);

            modelBuilder.Entity<TBLlogindetail>()
                .Property(e => e.loginid)
                .IsUnicode(false);

            modelBuilder.Entity<TBLlogindetail>()
                .Property(e => e.loginintime)
                .IsUnicode(false);

            modelBuilder.Entity<TBLlogindetail>()
                .Property(e => e.loginouttime)
                .IsUnicode(false);

            modelBuilder.Entity<tblorder>()
                .Property(e => e.receiverid)
                .IsUnicode(false);

            modelBuilder.Entity<tblorder>()
                .Property(e => e.receivedrate)
                .IsUnicode(false);

            modelBuilder.Entity<tblorder>()
                .Property(e => e.photcopy)
                .IsUnicode(false);

            modelBuilder.Entity<tblorder>()
                .HasMany(e => e.tblorderdetails)
                .WithRequired(e => e.tblorder)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<tblorder>()
                .HasMany(e => e.tblpurchases)
                .WithRequired(e => e.tblorder)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<TBLpatient>()
                .Property(e => e.name)
                .IsUnicode(false);

            modelBuilder.Entity<TBLpatient>()
                .Property(e => e.mobile)
                .IsUnicode(false);

            modelBuilder.Entity<TBLpatient>()
                .Property(e => e.email)
                .IsUnicode(false);

            modelBuilder.Entity<TBLpatient>()
                .Property(e => e.address)
                .IsUnicode(false);

            modelBuilder.Entity<TBLpatient>()
                .Property(e => e.occupation)
                .IsUnicode(false);

            modelBuilder.Entity<TBLpatient>()
                .Property(e => e.cardno)
                .IsUnicode(false);

            modelBuilder.Entity<TBLpatient>()
                .HasMany(e => e.tbladmitdetails)
                .WithRequired(e => e.TBLpatient)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<TBLpatient>()
                .HasMany(e => e.tblappointments)
                .WithRequired(e => e.TBLpatient)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<TBLpatient>()
                .HasMany(e => e.tbltherapydetails)
                .WithRequired(e => e.TBLpatient)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<tblpurchase>()
                .Property(e => e.userid)
                .IsUnicode(false);

            modelBuilder.Entity<tblpurchase>()
                .Property(e => e.photcopy)
                .IsUnicode(false);

            modelBuilder.Entity<tblpurchase>()
                .HasMany(e => e.tblbills)
                .WithRequired(e => e.tblpurchase)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<tblpurchase>()
                .HasMany(e => e.tblpurchasedetails)
                .WithRequired(e => e.tblpurchase)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<tblpurchasedetail>()
                .Property(e => e.rate)
                .HasPrecision(18, 0);

            modelBuilder.Entity<tblpurchasedetail>()
                .Property(e => e.type)
                .IsUnicode(false);

            modelBuilder.Entity<tblpurchasedetail>()
                .Property(e => e.batchno)
                .IsUnicode(false);

            modelBuilder.Entity<tblroom>()
                .Property(e => e.roomlocation)
                .IsUnicode(false);

            modelBuilder.Entity<tblroom>()
                .HasMany(e => e.tblbeds)
                .WithRequired(e => e.tblroom)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<tblroomtype>()
                .Property(e => e.roomtype)
                .IsUnicode(false);

            modelBuilder.Entity<tblroomtype>()
                .Property(e => e.roomprice)
                .IsUnicode(false);

            modelBuilder.Entity<tblroomtype>()
                .Property(e => e.roomdiscription)
                .IsUnicode(false);

            modelBuilder.Entity<tblroomtype>()
                .HasMany(e => e.tblrooms)
                .WithRequired(e => e.tblroomtype)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<tbltheoreapylog>()
                .Property(e => e.entrydate)
                .IsUnicode(false);

            modelBuilder.Entity<tbltheoreapylog>()
                .Property(e => e.entryby)
                .IsUnicode(false);

            modelBuilder.Entity<tbltheoreapylog>()
                .Property(e => e.comment)
                .IsUnicode(false);

            modelBuilder.Entity<tbltheoreapylog>()
                .Property(e => e.feedback)
                .IsUnicode(false);

            modelBuilder.Entity<tbltherapydetail>()
                .Property(e => e.caretaker)
                .IsUnicode(false);

            modelBuilder.Entity<tbltherapydetail>()
                .Property(e => e.supervior)
                .IsUnicode(false);

            modelBuilder.Entity<tbltherapydetail>()
                .Property(e => e.fromdate)
                .IsUnicode(false);

            modelBuilder.Entity<tbltherapydetail>()
                .Property(e => e.todate)
                .IsUnicode(false);

            modelBuilder.Entity<tbltherapydetail>()
                .Property(e => e.entrydate)
                .IsUnicode(false);

            modelBuilder.Entity<tbltherapydetail>()
                .Property(e => e.entryby)
                .IsUnicode(false);

            modelBuilder.Entity<tbltherapydetail>()
                .HasMany(e => e.tbltheoreapylogs)
                .WithRequired(e => e.tbltherapydetail)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<tbltreatementtype>()
                .Property(e => e.treatmenttype)
                .IsUnicode(false);

            modelBuilder.Entity<tbltreatementtype>()
                .Property(e => e.treatmentdescription)
                .IsUnicode(false);

            modelBuilder.Entity<tbltreatementtype>()
                .HasMany(e => e.tbltherapydetails)
                .WithRequired(e => e.tbltreatementtype)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<tbltreatment>()
                .HasMany(e => e.tbltreatmentdetails)
                .WithRequired(e => e.tbltreatment)
                .HasForeignKey(e => e.treamentid)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<tbltreatmentdetail>()
                .Property(e => e.treatmentdetails)
                .IsUnicode(false);

            modelBuilder.Entity<tbltreatmentdetail>()
                .HasMany(e => e.tbltreatmenttabletdetails)
                .WithRequired(e => e.tbltreatmentdetail)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<tbltreatmenttabletdetail>()
                .Property(e => e.dosagedetails)
                .IsUnicode(false);
        }
    }
}
