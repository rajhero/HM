namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("tblitem")]
    public partial class tblitem
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public tblitem()
        {
            tblorderdetails = new HashSet<tblorderdetail>();
        }

        [Key]
        public int itemid { get; set; }

        public int? itemtypeid { get; set; }

        public string itemdescription { get; set; }

        public string item { get; set; }

        public virtual tblItemtype tblItemtype { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tblorderdetail> tblorderdetails { get; set; }
    }
}
