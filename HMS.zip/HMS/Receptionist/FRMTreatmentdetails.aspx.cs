﻿using HMS.DAL;
using HMS.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HMS.Receptionist
{
    public partial class FRMTreatmentdetails : System.Web.UI.Page
    {
        private UnitOfWork objUnitOfWork = new UnitOfWork();
        private ServiceModel objServiceModel = new ServiceModel();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["controllerID"] != null)
            {
                if (!this.IsPostBack)
                {
                    GetTreatmentdetails(); Clear(); fillddlappointment(); filltablet(); filldisease();
                }
            }
        }

        private void filldisease()
        {
            var source = objUnitOfWork.TbldiseaseRepository.Get();

            if (source.Any())
            {

                ddlDesease.DataSource = source;
                ddlDesease.DataTextField = "diseasename";
                ddlDesease.DataValueField = "diseaseid";
                ddlDesease.DataBind();
            }
            ddlDesease.Items.Insert(0, "Select");
        }

        private void filltablet()
        {
            var source = objUnitOfWork.TbltabletRepository.Get();

            if (source.Any())
            {

                ddlTablet.DataSource = source;
                ddlTablet.DataTextField = "tablet";
                ddlTablet.DataValueField = "tabletsid";
                ddlTablet.DataBind();
            }
            ddlTablet.Items.Insert(0, "Select");
        }

        private void fillddlappointment()
        {
            var source = objUnitOfWork.tblappointment.Get();

            if (source.Any())
            {
                
        ddlAppointment.DataSource = source;
                ddlAppointment.DataTextField = "datetime";
                ddlAppointment.DataValueField = "appointmentid";
                ddlAppointment.DataBind();
            }
            ddlAppointment.Items.Insert(0, "Select");
        }

        private void GetTreatmentdetails()
        {
            var tablet = objUnitOfWork.tbltreatment.Get().
                 Join(objServiceModel.Tblappointments,
                    ac => ac.appointmentid,
                    de => de.appointmentid,
                    (ac, de) =>
                        new
                        {
                            appointmentid = ac.appointmentid,
                            treatmentdate = ac.treatmentdate,
                            treatmentid = ac.treatmentid,
                            doctor = de.doctor,
                            patientid = de.patientid,
                            starttime = de.starttime,
                            endtime = de.endtime,

                            location = de.location


                        }).Join(objServiceModel.TBLpatients,
                    ac => ac.patientid,
                    de => de.patientid,
                    (ac, de) =>
                        new
                        {
                            appointmentid = ac.appointmentid,
                            treatmentdate = ac.treatmentdate,
                            treatmentid = ac.treatmentid,
                            doctor = ac.doctor,
                            patientid = ac.patientid,
                            starttime = ac.starttime,
                            endtime = ac.endtime,
                            location = ac.location,
                            patientname = de.name


                        }).Join(objServiceModel.TBLaccount,
                    ac => ac.doctor,
                    de => de.loginID,
                    (ac, de) =>
                        new
                        {
                            appointmentid = ac.appointmentid,
                            treatmentdate = ac.treatmentdate,
                            treatmentid = ac.treatmentid,
                            doctor = ac.doctor,
                            patientid = ac.patientid,
                            starttime = ac.starttime,
                            endtime = ac.endtime,
                            location = ac.location,
                            patientname = de.name,
                            doctorname = de.name,
                            appoitmentdatetime = ac.starttime + "-" + ac.endtime,


                        })
                .OrderBy(d => d.treatmentdate);
            bool any = tablet.Any();

            if (!any)
            {
                Treatmentview.EmptyDataText = "No records found!!";
            }
            else
            {
                if (Treatmentview != null)
                {
                    Treatmentview.DataSource = tablet;
                    Treatmentview.DataBind();
                }
            }
        }

        private void Clear()
        {
            ddlAppointment.SelectedIndex = ddlDesease.SelectedIndex = ddlTablet.SelectedIndex = 0;
        }

        protected void ddlAppointment_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlAppointment.SelectedIndex > 0 && ddlAppointment.SelectedIndex != -1)
            {
                var appointment = objUnitOfWork.tblappointment.Get().
                 Join(objServiceModel.Tblappointments,
                    ac => ac.appointmentid,
                    de => de.appointmentid,
                    (ac, de) =>
                        new
                        {
                            appointmentid = ac.appointmentid,
                            doctor = de.doctor,
                            patientid = de.patientid,
                            starttime = de.starttime,
                            endtime = de.endtime,

                            location = de.location



                        }).Join(objServiceModel.TBLpatients,
                    ac => ac.patientid,
                    de => de.patientid,
                    (ac, de) =>
                        new
                        {
                            appointmentid = ac.appointmentid,
                            doctor = ac.doctor,
                            patientid = ac.patientid,
                            starttime = ac.starttime,
                            endtime = ac.endtime,
                            location = ac.location,
                            patientname = de.name


                        }).Join(objServiceModel.TBLaccount,
                    ac => ac.doctor,
                    de => de.loginID,
                    (ac, de) =>
                        new
                        {
                            appointmentid = ac.appointmentid,
                            patientid = ac.patientid,
                            starttime = ac.starttime,
                            endtime = ac.endtime,
                            location = ac.location,
                            patientname = de.name,
                            doctorname = de.name,
                            appoitmentdatetime = ac.starttime + "-" + ac.endtime,


                        }).Where(d => d.appointmentid == Convert.ToInt32(ddlAppointment.SelectedItem.Value));
                if (appointment.Any())
                {
                    grdAppointmentdetails.DataSource = appointment;
                    grdAppointmentdetails.DataBind();
                }
                else
                {
                    grdAppointmentdetails.EmptyDataText = "No records found!!";
                }

            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (btnSubmit.Text == "Submit")
            {
                
                tbltreatment tbltreatment = new tbltreatment
                {
                    treatmentdate = DateTime.Now,
                    appointmentid = Convert.ToInt32(ddlAppointment.SelectedItem.Value)

                };
                objUnitOfWork.tbltreatment.Insert(tbltreatment);
                if (objUnitOfWork.Save() > 0)
                {
                    

                    tbltreatmentdetail tbltreatmentdetail = new tbltreatmentdetail {
                        deseaseid = Convert.ToInt32(ddlDesease.SelectedItem.Value),
                        treamentid= tbltreatment.treatmentid
                    };
                    objUnitOfWork.tbltreatmentdetail.Insert(tbltreatmentdetail);
                    if (objUnitOfWork.Save() > 0)
                    {
                        tbltreatmenttabletdetail tbltreatmenttabletdetail = new tbltreatmenttabletdetail {

                            tabletid = Convert.ToInt32(ddlTablet.SelectedItem.Value),
                            treatmentdetailsid=tbltreatmentdetail.treatmentdetailsid


                        };
                        objUnitOfWork.tbltreatmenttabletdetail.Insert(tbltreatmenttabletdetail);
                        if (objUnitOfWork.Save() > 0)
                        {
                            lblMsg.Text = "Records successfully inserted";
                        }

                    };
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
            else if (btnSubmit.Text == "Edit")
            {
                tbltreatment tbltreatment = new tbltreatment
                {
                    treatmentdate = DateTime.Now,
                    appointmentid = Convert.ToInt32(ddlAppointment.SelectedItem.Value)

                };
                objUnitOfWork.tbltreatment.Update(tbltreatment);
                if (objUnitOfWork.Save() > 0)
                {

                    
                    for (int i = 0; i < selectedItemsPanel.Controls.Count; i++)
                    {
                        tbltreatmentdetail tbltreatmentdetail = new tbltreatmentdetail
                        {
                            deseaseid = Convert.ToInt32(ddlDesease.SelectedItem.Value),
                            treamentid = tbltreatment.treatmentid
                        };
                        objUnitOfWork.tbltreatmentdetail.Update(tbltreatmentdetail);
                        if (objUnitOfWork.Save() > 0)
                        {
                            tbltreatmenttabletdetail tbltreatmenttabletdetail = new tbltreatmenttabletdetail
                            {

                                tabletid = Convert.ToInt32(ddlTablet.SelectedItem.Value),
                                treatmentdetailsid = tbltreatmentdetail.treatmentdetailsid


                            };
                            objUnitOfWork.tbltreatmenttabletdetail.Update(tbltreatmenttabletdetail);
                            if (objUnitOfWork.Save() > 0)
                            {
                                lblMsg.Text = "Records successfully Updated";
                            }

                        }; 
                    }


                }
                else { lblMsg.Text = "Server Interrupted!!"; }


            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {

        }
        static DataTable dtDiseasespcification = new DataTable();
        protected void btnAddDiseaseSpecification_Click(object sender, EventArgs e)
        {

            //selectedItemsPanel.Controls.Clear();
            int pnlid = 0;
            foreach (ListItem item in (DropDown1 as ListControl).Items)
            {
                if (item.Selected)
                    selectedItemsPanel.Controls.Add(new Literal() { ID =pnlid.ToString(), Text = item.Text + " : " + item.Value + "<br/>" });
            pnlid++;
            }
        }
    }
}