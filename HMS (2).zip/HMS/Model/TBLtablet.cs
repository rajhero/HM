namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class TBLtablet
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public TBLtablet()
        {
            tblorderdetails = new HashSet<tblorderdetail>();
            tbltreatmenttabletdetails = new HashSet<tbltreatmenttabletdetail>();
        }

        [Key]
        public int tabletid { get; set; }

        public string tablet { get; set; }

        public string tabletdescription { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tblorderdetail> tblorderdetails { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tbltreatmenttabletdetail> tbltreatmenttabletdetails { get; set; }
    }
}
