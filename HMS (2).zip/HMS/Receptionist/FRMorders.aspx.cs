﻿using HMS.DAL;
using HMS.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HMS.Receptionist
{
    public partial class FRMorders : System.Web.UI.Page
    {
         
         private UnitOfWork objUnitOfWork = new UnitOfWork();
        private ServiceModel objServiceModel = new ServiceModel();
        private void SetInitialRow()
        {
            DataTable dt = new DataTable();
            DataRow dr = null;
            dt.Columns.Add(new DataColumn("Item", typeof(string)));
            dt.Columns.Add(new DataColumn("Qty", typeof(string)));
            
            dr = dt.NewRow();
            dr["Item"] = string.Empty;
            dr["Qty"] = string.Empty;
            dt.Rows.Add(dr);

            //Store the DataTable in ViewState
            ViewState["CurrentTable"] = dt;

            Gridview1.DataSource = dt;
            Gridview1.DataBind();
        }
        private void AddNewRowToGrid()
        {
            int rowIndex = 0;

            if (ViewState["CurrentTable"] != null)
            {
                DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
                DataRow drCurrentRow = null;
                if (dtCurrentTable.Rows.Count > 0)
                {
                    for (int i = 1; i <= dtCurrentTable.Rows.Count; i++)
                    {
                        //extract the TextBox values
                        DropDownList box1 = (DropDownList)Gridview1.Rows[rowIndex].Cells[1].FindControl("ddltablet");
                        TextBox box2 = (TextBox)Gridview1.Rows[rowIndex].Cells[2].FindControl("txtqty");
                     

                        drCurrentRow = dtCurrentTable.NewRow();
                        drCurrentRow["RowNumber"] = i + 1;

                        dtCurrentTable.Rows[i - 1]["Item"] = box1.SelectedItem.Value;
                        dtCurrentTable.Rows[i - 1]["qty"] = box2.Text;
                       

                        rowIndex++;
                    }
                    dtCurrentTable.Rows.Add(drCurrentRow);
                    ViewState["CurrentTable"] = dtCurrentTable;

                    Gridview1.DataSource = dtCurrentTable;
                    Gridview1.DataBind();
                }
            }
            else
            {
                Response.Write("ViewState is null");
            }

            //Set Previous Data on Postbacks
            SetPreviousData();
        }
        private void SetPreviousData()
        {
            int rowIndex = 0;
            if (ViewState["CurrentTable"] != null)
            {
                DataTable dt = (DataTable)ViewState["CurrentTable"];
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        DropDownList box1 = (DropDownList)Gridview1.Rows[rowIndex].Cells[1].FindControl("ddltablet");
                        TextBox box2 = (TextBox)Gridview1.Rows[rowIndex].Cells[2].FindControl("txtqty");
                        int _tabletid = Convert.ToInt32(box1.SelectedItem.Value);
                       // var source = objUnitOfWork.TbltabletRepository.Get().Where(d=>d.tabletid== _tabletid);
                        box1.SelectedIndex =box1.Items.IndexOf(box1.Items.FindByValue( dt.Rows[i]["Item"].ToString()));
                        box2.Text = dt.Rows[i]["qty"].ToString();
                      

                        rowIndex++;
                    }
                }
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                SetInitialRow();
            }
        }
        protected void ButtonAdd_Click(object sender, EventArgs e)
        {
            AddNewRowToGrid();
        }

        protected void Gridview1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            DropDownList dropDownList = new DropDownList();
            var source = objUnitOfWork.tblitemRepository.Get().OrderBy(d => d.itemid);
            if (source.Any())
            {
                dropDownList.DataSource = source;
                dropDownList.DataTextField = "tablet";
                dropDownList.DataValueField = "tabletid";
                dropDownList.DataBind();
            }
            else
            {
                dropDownList.Items.Insert(0, "No Records Found!!");
            }
            dropDownList.Items.Insert(0, "Select");
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (btnSubmit.Text == "Submit")
            {

                tblorder tblorder  = new tblorder
                {


                     distributorid=Convert.ToInt32(ddldistributor.SelectedItem.Value),
                    orderdate = DateTime.Now,
                     receiverid = Session["controllerID"].ToString(),
                     photcopy="",
                     receivedrate="0",
                };
                objUnitOfWork.tblorder.Insert(tblorder);
                if (objUnitOfWork.Save() > 0)
                {
                    if (Gridview1.Rows.Count > 0)
                    {
                        for (int i = 0; i < Gridview1.Rows.Count; i++)
                        {
                             
                            int qty = Convert.ToInt32(Gridview1.Rows[i].Cells[2].Text);
                            
                            DropDownList ddltablet = (DropDownList)Gridview1.Rows[i].Cells[0].FindControl("ddltablet");
                           
                            tblorderdetail tblorderdetail = new tblorderdetail
                            {

                                orderid = tblorder.Orderid,
                                tablet = Convert.ToInt32(ddltablet.SelectedItem.Value),
                                qty = qty,
                                


                            };
                            objUnitOfWork.tblorderdetail.Insert(tblorderdetail);
                        }
                        if (objUnitOfWork.Save() > 0)
                        {
                            lblMsg.Text = "Records successfully inserted";
                        }
                        else { lblMsg.Text = "Server Interrupted!!"; }
                    }
                    lblMsg.Text = "Records successfully inserted";
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
           
        }
    }
}