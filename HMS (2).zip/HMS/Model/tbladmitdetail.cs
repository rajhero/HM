namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class tbladmitdetail
    {
        [Key]
        public int admitdetailsid { get; set; }

        public int patientid { get; set; }

        [StringLength(50)]
        public string datetime { get; set; }

        [StringLength(50)]
        public string status { get; set; }

        public int? bedid { get; set; }

        [StringLength(50)]
        public string fromdate { get; set; }

        [StringLength(50)]
        public string todate { get; set; }

        [StringLength(50)]
        public string entrydate { get; set; }

        [StringLength(50)]
        public string entryby { get; set; }

        public virtual tblbed tblbed { get; set; }

        public virtual TBLpatient TBLpatient { get; set; }
    }
}
