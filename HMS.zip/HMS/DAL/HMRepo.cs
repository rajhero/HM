﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.Entity;
using HMS.Model;
using System.Linq.Expressions;

namespace HMS.DAL
{
    #region old

    //public class HMRepo<TEntity> where TEntity : class
    //{
    //    internal ServiceModel context;
    //    internal DbSet<TEntity> dbSet;

    //    public HMRepo(ServiceModel context)
    //    {
    //        this.context = context;
    //        this.dbSet = context.Set<TEntity>();
    //    }

    //    public virtual IEnumerable<TEntity> Get(
    //        Expression<Func<TEntity, bool>> filter = null,
    //        Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null,
    //        string includeProperties = "")
    //    {
    //        IQueryable<TEntity> query = dbSet;

    //        if (filter != null)
    //        {
    //            query = query.Where(filter);
    //        }

    //        foreach (var includeProperty in includeProperties.Split
    //            (new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
    //        {
    //            query = query.Include(includeProperty);
    //        }

    //        if (orderBy != null)
    //        {
    //            return orderBy(query).ToList();
    //        }
    //        else
    //        {
    //            return query.ToList();
    //        }
    //    }

    //    public virtual TEntity GetByID(object id)
    //    {
    //        return dbSet.Find(id);
    //    }

    //    public virtual void Insert(TEntity entity)
    //    {
    //        dbSet.Add(entity);
    //    }

    //    public virtual void Delete(object id)
    //    {
    //        TEntity entityToDelete = dbSet.Find(id);
    //        Delete(entityToDelete);
    //    }

    //    public virtual void Delete(TEntity entityToDelete)
    //    {
    //        if (context.Entry(entityToDelete).State == EntityState.Detached)
    //        {
    //            dbSet.Attach(entityToDelete);
    //        }
    //        dbSet.Remove(entityToDelete);
    //    }

    //    public virtual void Update(TEntity entityToUpdate)
    //    {
    //        dbSet.Attach(entityToUpdate);
    //        context.Entry(entityToUpdate).State = EntityState.Modified;
    //    }
    //}
    //public class UnitOfWork : IDisposable
    //{
    //    private ServiceModel context = new ServiceModel();
    //    private HMRepo<TBLaccount> TBLaccountRepository;
    //    private HMRepo<TBLlogindetail> TBLlogindetailRepository;
    //    private HMRepo<TBLdisease> TBLdiseaseRepository;
    //    private HMRepo<TBLtablet> TBLtablet;
    //    public HMRepo<TBLtablet> TbltabletRepository
    //    {
    //        get
    //        {

    //            if (this.TbltabletRepository == null)
    //            {
    //                this.TBLtablet = new HMRepo<TBLtablet>(context);
    //            }
    //            return TbltabletRepository;
    //        }
    //    }
    //    private HMRepo<TBLdistributordetail> TBLdistributordetailRepository;
    //    public HMRepo<TBLdistributordetail> Tbldistributordetail
    //    {
    //        get
    //        {

    //            if (this.Tbldistributordetail == null)
    //            {
    //                this.TBLdistributordetailRepository = new HMRepo<TBLdistributordetail>(context);
    //            }
    //            return Tbldistributordetail;
    //        }
    //    }

    //    private HMRepo<tblappointment> TBLappointmentRepository;
    //    public HMRepo<tblappointment> tblappointment
    //    {
    //        get
    //        {

    //            if (this.tblappointment == null)
    //            {
    //                this.TBLappointmentRepository = new HMRepo<tblappointment>(context);
    //            }
    //            return tblappointment;
    //        }
    //    }

    //    private HMRepo<tblbill> TBLbillRepository;
    //    public HMRepo<tblbill> tblbill
    //    {
    //        get
    //        {

    //            if (this.tblbill == null)
    //            {
    //                this.TBLbillRepository = new HMRepo<tblbill>(context);
    //            }
    //            return tblbill;
    //        }
    //    }

    //    private HMRepo<tblenquiry> TBLenquiryRepository;
    //    public HMRepo<tblenquiry> tblenquiry
    //    {
    //        get
    //        {

    //            if (this.tblenquiry == null)
    //            {
    //                this.TBLenquiryRepository = new HMRepo<tblenquiry>(context);
    //            }
    //            return tblenquiry;
    //        }
    //    }

    //    private HMRepo<tblorder> TBLorderRepository;
    //    public HMRepo<tblorder> tblorder
    //    {
    //        get
    //        {

    //            if (this.tblorder == null)
    //            {
    //                this.TBLorderRepository = new HMRepo<tblorder>(context);
    //            }
    //            return tblorder;
    //        }
    //    }

    //    private HMRepo<tblorderdetail> TBLorderdetailRepository;
    //    public HMRepo<tblorderdetail> tblorderdetail
    //    {
    //        get
    //        {

    //            if (this.tblorderdetail == null)
    //            {
    //                this.TBLorderdetailRepository = new HMRepo<tblorderdetail>(context);
    //            }
    //            return tblorderdetail;
    //        }
    //    }

    //    private HMRepo<tblpurchase> TBLpurchaseRepository;
    //    public HMRepo<tblpurchase> tblpurchase
    //    {
    //        get
    //        {

    //            if (this.tblpurchase == null)
    //            {
    //                this.TBLpurchaseRepository = new HMRepo<tblpurchase>(context);
    //            }
    //            return tblpurchase;
    //        }
    //    }

    //    private HMRepo<tblpurchasedetail> TBLpurchasedetailRepository;
    //    public HMRepo<tblpurchasedetail> tblpurchasedetail
    //    {
    //        get
    //        {

    //            if (this.tblpurchasedetail == null)
    //            {
    //                this.TBLpurchasedetailRepository = new HMRepo<tblpurchasedetail>(context);
    //            }
    //            return tblpurchasedetail;
    //        }
    //    }

    //    private HMRepo<tbltreatment> TBLtreatmentRepository;
    //    public HMRepo<tbltreatment> tbltreatment
    //    {
    //        get
    //        {

    //            if (this.tbltreatment == null)
    //            {
    //                this.TBLtreatmentRepository = new HMRepo<tbltreatment>(context);
    //            }
    //            return tbltreatment;
    //        }
    //    }
    //    private HMRepo<tbltreatmentdetail> TBLtreatmentdetailRepository;
    //    public HMRepo<tbltreatmentdetail> tbltreatmentdetail
    //    {
    //        get
    //        {

    //            if (this.tbltreatmentdetail == null)
    //            {
    //                this.TBLtreatmentdetailRepository = new HMRepo<tbltreatmentdetail>(context);
    //            }
    //            return tbltreatmentdetail;
    //        }
    //    }

    //    private HMRepo<tbltreatmenttabletdetail> TbltreatmenttabletdetailRepository;
    //    public HMRepo<tbltreatmenttabletdetail> tbltreatmenttabletdetail
    //    {
    //        get
    //        {

    //            if (this.tbltreatmenttabletdetail == null)
    //            {
    //                this.TbltreatmenttabletdetailRepository = new HMRepo<tbltreatmenttabletdetail>(context);
    //            }
    //            return tbltreatmenttabletdetail;
    //        }
    //    }

    //    private HMRepo<TBLpatient> TBLpatientRepository;

    //    public HMRepo<TBLpatient> Tblpatient
    //    {
    //        get
    //        {

    //            if (this.Tblpatient == null)
    //            {
    //                this.TBLpatientRepository = new HMRepo<TBLpatient>(context);
    //            }
    //            return Tblpatient;
    //        }
    //    }

    //    public HMRepo<TBLaccount> TblaccountRepository
    //    {
    //        get
    //        {

    //            if (this.TblaccountRepository == null)
    //            {
    //                this.TBLaccountRepository = new HMRepo<TBLaccount>(context);
    //            }
    //            return TblaccountRepository;
    //        }
    //    }

    //    public HMRepo<TBLlogindetail> TbllogindetailRepository
    //    {
    //        get
    //        {

    //            if (this.TbllogindetailRepository == null)
    //            {
    //                this.TBLlogindetailRepository = new HMRepo<TBLlogindetail>(context);
    //            }
    //            return TbllogindetailRepository;
    //        }
    //    }
    //    public HMRepo<TBLdisease> TbldiseaseRepository
    //    {
    //        get
    //        {

    //            if (this.TbldiseaseRepository == null)
    //            {
    //                this.TBLdiseaseRepository = new HMRepo<TBLdisease>(context);
    //            }
    //            return TbldiseaseRepository;
    //        }
    //    }
    //    private HMRepo<TBLdesignation> TBLdesignation;
    //    public HMRepo<TBLdesignation> TbldesignationRepository
    //    {
    //        get
    //        {

    //            if (this.TbldesignationRepository == null)
    //            {
    //                this.TBLdesignation = new HMRepo<TBLdesignation>(context);
    //            }
    //            return TbldesignationRepository;
    //        }
    //    }

    //    private HMRepo<tblbed> TBLbed;
    //    public HMRepo<tblbed> tblbedRepository
    //    {
    //        get
    //        {

    //            if (this.tblbedRepository == null)
    //            {
    //                this.TBLbed = new HMRepo<tblbed>(context);
    //            }
    //            return tblbedRepository;
    //        }
    //    }

    //    private HMRepo<tblbedtype> TBLbedtype;
    //    public HMRepo<tblbedtype> tblbedtypeRepository
    //    {
    //        get
    //        {

    //            if (this.tblbedtypeRepository == null)
    //            {
    //                this.TBLbedtype = new HMRepo<tblbedtype>(context);
    //            }
    //            return tblbedtypeRepository;
    //        }
    //    }
    //    private HMRepo<tblroom> TBLroom;
    //    public HMRepo<tblroom> tblroomRepository
    //    {
    //        get
    //        {

    //            if (this.tblroomRepository == null)
    //            {
    //                this.TBLroom = new HMRepo<tblroom>(context);
    //            }
    //            return tblroomRepository;
    //        }
    //    }
    //    private HMRepo<tblroomtype> TBLroomtype;
    //    public HMRepo<tblroomtype> tblroomtypeRepository
    //    {
    //        get
    //        {

    //            if (this.tblroomtypeRepository == null)
    //            {
    //                this.TBLroomtype = new HMRepo<tblroomtype>(context);
    //            }
    //            return tblroomtypeRepository;
    //        }
    //    }

    //          private HMRepo<tbltreatementtype> TBLtreatementtype;
    //    public HMRepo<tbltreatementtype> tbltreatementtypeRepository
    //    {
    //        get
    //        {

    //            if (this.tbltreatementtypeRepository == null)
    //            {
    //                this.TBLtreatementtype = new HMRepo<tbltreatementtype>(context);
    //            }
    //            return tbltreatementtypeRepository;
    //        }
    //    }
    //    private HMRepo<tblattribute> tblattribute;
    //    public HMRepo<tblattribute> TblattributeRepository
    //    {
    //        get
    //        {

    //            if (this.TblattributeRepository == null)
    //            {
    //                this.tblattribute = new HMRepo<tblattribute>(context);
    //            }
    //            return TblattributeRepository;
    //        }
    //    }
    //    private HMRepo<tblBillDetails> tblBillDetails;
    //    public HMRepo<tblBillDetails> tblBillDetailsRepository
    //    {
    //        get
    //        {

    //            if (this.tblBillDetailsRepository == null)
    //            {
    //                this.tblBillDetails = new HMRepo<tblBillDetails>(context);
    //            }
    //            return tblBillDetailsRepository;
    //        }
    //    }
    //    public int Save()
    //    {
    //        return context.SaveChanges();
    //    }

    //    private bool disposed = false;

    //    protected virtual void Dispose(bool disposing)
    //    {
    //        if (!this.disposed)
    //        {
    //            if (disposing)
    //            {
    //                context.Dispose();
    //            }
    //        }
    //        this.disposed = true;
    //    }

    //    public void Dispose()
    //    {
    //        Dispose(true);
    //        GC.SuppressFinalize(this);
    //    }
    //} 
    #endregion

    public class HMRepo<TEntity> where TEntity : class
    {
        internal ServiceModel context;
        internal DbSet<TEntity> dbSet;

        public HMRepo(ServiceModel context)
        {
            this.context = context;
            this.dbSet = context.Set<TEntity>();
        }

        public virtual IEnumerable<TEntity> Get(
            Expression<Func<TEntity, bool>> filter = null,
            Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null,
            string includeProperties = "")
        {
            IQueryable<TEntity> query = dbSet;

            if (filter != null)
            {
                query = query.Where(filter);
            }

            foreach (var includeProperty in includeProperties.Split
                (new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
            {
                query = query.Include(includeProperty);
            }

            if (orderBy != null)
            {
                return orderBy(query).ToList();
            }
            else
            {
                return query.ToList();
            }
        }

        public virtual TEntity GetByID(object id)
        {
            return dbSet.Find(id);
        }

        public virtual void Insert(TEntity entity)
        {
            dbSet.Add(entity);
        }

        public virtual void Delete(object id)
        {
            TEntity entityToDelete = dbSet.Find(id);
            Delete(entityToDelete);
        }

        public virtual void Delete(TEntity entityToDelete)
        {
            if (context.Entry(entityToDelete).State == EntityState.Detached)
            {
                dbSet.Attach(entityToDelete);
            }
            dbSet.Remove(entityToDelete);
        }

        public virtual void Update(TEntity entityToUpdate)
        {
            dbSet.Attach(entityToUpdate);
            context.Entry(entityToUpdate).State = EntityState.Modified;
        }
    }
    public class UnitOfWork : IDisposable
    {
        private ServiceModel context = new ServiceModel();
        private HMRepo<TBLaccount> TBLaccountRepository;
        private HMRepo<TBLlogindetail> TBLlogindetailRepository;
        private HMRepo<TBLdisease> TBLdiseaseRepository;
        private HMRepo<tblitem> tblitem;
        public HMRepo<tblitem> tblitemRepository
        {
            get
            {

                if (this.tblitem == null)
                {
                    this.tblitem = new HMRepo<tblitem>(context);
                }
                return tblitem;
            }
        }
        private HMRepo<tblItemtype> tblItemtype;
        public HMRepo<tblItemtype> tblItemtypeRepository
        {
            get
            {

                if (this.tblItemtype == null)
                {
                    this.tblItemtype = new HMRepo<tblItemtype>(context);
                }
                return tblItemtype;
            }
        }
        private HMRepo<tbldepartment> tbldepartment;
        public HMRepo<tbldepartment> tbldepartmentRepository
        {
            get
            {

                if (tbldepartment == null)
                {
                    tbldepartment = new HMRepo<tbldepartment>(context);
                }
                return tbldepartment;
            }
        }
        private HMRepo<TBLdistributordetail> TBLdistributordetailRepository;
        public HMRepo<TBLdistributordetail> Tbldistributordetail
        {
            get
            {

                if (this.TBLdistributordetailRepository == null)
                {
                    this.TBLdistributordetailRepository = new HMRepo<TBLdistributordetail>(context);
                }
                return TBLdistributordetailRepository;
            }
        }

        private HMRepo<tblappointment> TBLappointmentRepository;
        public HMRepo<tblappointment> tblappointment
        {
            get
            {

                if (this.TBLappointmentRepository == null)
                {
                    this.TBLappointmentRepository = new HMRepo<tblappointment>(context);
                }
                return TBLappointmentRepository;
            }
        }

        private HMRepo<tblbill> TBLbillRepository;
        public HMRepo<tblbill> tblbill
        {
            get
            {

                if (this.TBLbillRepository == null)
                {
                    this.TBLbillRepository = new HMRepo<tblbill>(context);
                }
                return TBLbillRepository;
            }
        }

        private HMRepo<tblenquiry> TBLenquiryRepository;
        public HMRepo<tblenquiry> tblenquiry
        {
            get
            {

                if (this.TBLenquiryRepository == null)
                {
                    this.TBLenquiryRepository = new HMRepo<tblenquiry>(context);
                }
                return TBLenquiryRepository;
            }
        }

        private HMRepo<tblorder> TBLorderRepository;
        public HMRepo<tblorder> tblorder
        {
            get
            {

                if (this.TBLorderRepository == null)
                {
                    this.TBLorderRepository = new HMRepo<tblorder>(context);
                }
                return TBLorderRepository;
            }
        }

        private HMRepo<tblorderdetail> TBLorderdetailRepository;
        public HMRepo<tblorderdetail> tblorderdetail
        {
            get
            {

                if (this.TBLorderdetailRepository == null)
                {
                    this.TBLorderdetailRepository = new HMRepo<tblorderdetail>(context);
                }
                return TBLorderdetailRepository;
            }
        }

        private HMRepo<tblpurchase> TBLpurchaseRepository;
        public HMRepo<tblpurchase> tblpurchase
        {
            get
            {

                if (this.TBLpurchaseRepository == null)
                {
                    this.TBLpurchaseRepository = new HMRepo<tblpurchase>(context);
                }
                return TBLpurchaseRepository;
            }
        }

        private HMRepo<tblpurchasedetail> TBLpurchasedetailRepository;
        public HMRepo<tblpurchasedetail> tblpurchasedetail
        {
            get
            {

                if (this.TBLpurchasedetailRepository == null)
                {
                    this.TBLpurchasedetailRepository = new HMRepo<tblpurchasedetail>(context);
                }
                return TBLpurchasedetailRepository;
            }
        }

        private HMRepo<tbltreatment> TBLtreatmentRepository;
        public HMRepo<tbltreatment> tbltreatment
        {
            get
            {

                if (this.TBLtreatmentRepository == null)
                {
                    this.TBLtreatmentRepository = new HMRepo<tbltreatment>(context);
                }
                return TBLtreatmentRepository;
            }
        }
        private HMRepo<tbltreatmentdetail> TBLtreatmentdetailRepository;
        public HMRepo<tbltreatmentdetail> tbltreatmentdetail
        {
            get
            {

                if (this.TBLtreatmentdetailRepository == null)
                {
                    this.TBLtreatmentdetailRepository = new HMRepo<tbltreatmentdetail>(context);
                }
                return TBLtreatmentdetailRepository;
            }
        }

        private HMRepo<tbltreatmenttabletdetail> TbltreatmenttabletdetailRepository;
        public HMRepo<tbltreatmenttabletdetail> tbltreatmenttabletdetail
        {
            get
            {

                if (this.TbltreatmenttabletdetailRepository == null)
                {
                    this.TbltreatmenttabletdetailRepository = new HMRepo<tbltreatmenttabletdetail>(context);
                }
                return TbltreatmenttabletdetailRepository;
            }
        }

        private HMRepo<TBLpatient> TBLpatientRepository;

        public HMRepo<TBLpatient> Tblpatient
        {
            get
            {

                if (this.TBLpatientRepository == null)
                {
                    this.TBLpatientRepository = new HMRepo<TBLpatient>(context);
                }
                return TBLpatientRepository;
            }
        }

        public HMRepo<TBLaccount> TblaccountRepository
        {
            get
            {

                if (this.TBLaccountRepository == null)
                {
                    this.TBLaccountRepository = new HMRepo<TBLaccount>(context);
                }
                return TBLaccountRepository;
            }
        }

        public HMRepo<TBLlogindetail> TbllogindetailRepository
        {
            get
            {

                if (this.TBLlogindetailRepository == null)
                {
                    this.TBLlogindetailRepository = new HMRepo<TBLlogindetail>(context);
                }
                return TBLlogindetailRepository;
            }
        }
        public HMRepo<TBLdisease> TbldiseaseRepository
        {
            get
            {

                if (this.TBLdiseaseRepository == null)
                {
                    this.TBLdiseaseRepository = new HMRepo<TBLdisease>(context);
                }
                return TBLdiseaseRepository;
            }
        }
        private HMRepo<TBLdesignation> TBLdesignation;
        public HMRepo<TBLdesignation> TbldesignationRepository
        {
            get
            {

                if (this.TBLdesignation == null)
                {
                    this.TBLdesignation = new HMRepo<TBLdesignation>(context);
                }
                return TBLdesignation;
            }
        }

        private HMRepo<tblbed> TBLbed;
        public HMRepo<tblbed> tblbedRepository
        {
            get
            {

                if (this.TBLbed == null)
                {
                    this.TBLbed = new HMRepo<tblbed>(context);
                }
                return TBLbed;
            }
        }

        private HMRepo<tblbedtype> TBLbedtype;
        public HMRepo<tblbedtype> tblbedtypeRepository
        {
            get
            {

                if (this.TBLbedtype == null)
                {
                    this.TBLbedtype = new HMRepo<tblbedtype>(context);
                }
                return TBLbedtype;
            }
        }
        private HMRepo<tblroom> TBLroom;
        public HMRepo<tblroom> tblroomRepository
        {
            get
            {

                if (this.TBLroom == null)
                {
                    this.TBLroom = new HMRepo<tblroom>(context);
                }
                return TBLroom;
            }
        }
        private HMRepo<tblroomtype> TBLroomtype;
        public HMRepo<tblroomtype> tblroomtypeRepository
        {
            get
            {

                if (this.TBLroomtype == null)
                {
                    this.TBLroomtype = new HMRepo<tblroomtype>(context);
                }
                return TBLroomtype;
            }
        }

        private HMRepo<tbltreatementtype> TBLtreatementtype;
        public HMRepo<tbltreatementtype> tbltreatementtypeRepository
        {
            get
            {

                if (this.TBLtreatementtype == null)
                {
                    this.TBLtreatementtype = new HMRepo<tbltreatementtype>(context);
                }
                return TBLtreatementtype;
            }
        }
        private HMRepo<tblattribute> tblattribute;
        public HMRepo<tblattribute> TblattributeRepository
        {
            get
            {

                if (this.tblattribute == null)
                {
                    this.tblattribute = new HMRepo<tblattribute>(context);
                }
                return tblattribute;
            }
        }
        private HMRepo<tblBilldetail> tblBillDetails;
        public HMRepo<tblBilldetail> tblBillDetailsRepository
        {
            get
            {

                if (this.tblBillDetails == null)
                {
                    this.tblBillDetails = new HMRepo<tblBilldetail>(context);
                }
                return tblBillDetails;
            }
        }
        private HMRepo<tbladmitdetail> tbladmitdetail;
        public HMRepo<tbladmitdetail> tbladmitdetailRepository
        {
            get
            {

                if (this.tbladmitdetail == null)
                {
                    this.tbladmitdetail = new HMRepo<tbladmitdetail>(context);
                }
                return tbladmitdetail;
            }
        }
        public int Save()
        {
          
            return context.SaveChanges();
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}