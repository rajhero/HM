namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("tblroom")]
    public partial class tblroom
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public tblroom()
        {
            tblbeds = new HashSet<tblbed>();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]

        public int roomid { get; set; }

        public int? roomno { get; set; }

        [StringLength(50)]
        public string roomlocation { get; set; }

        public int roomtypeid { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tblbed> tblbeds { get; set; }

        public virtual tblroomtype tblroomtype { get; set; }
    }
}
