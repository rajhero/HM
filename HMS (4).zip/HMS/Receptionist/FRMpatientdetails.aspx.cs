﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HMS.DAL;
using HMS.Model;

namespace HMS.Receptionist
{
    public partial class FRMpatientdetails : System.Web.UI.Page
    {

        private static int _patientID;

        public static int PatientID { get => _patientID; set => _patientID = value; }
        private UnitOfWork objUnitOfWork = new UnitOfWork();
        private ServiceModel objServiceModel = new ServiceModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["controllerID"] != null)
            {
                if (!this.IsPostBack)
                {

                    GetTbldistributordetail(); Clear();
                }
            }
        }

        private void Clear() => txtname.Text =
        txtemail.Text =
        txtaddress.Text =
        txtmobile.Text =
        txtoccupation.Text =
        txtcardno.Text = string.Empty;

        private void GetTbldistributordetail()
        {
            var source = objUnitOfWork.Tblpatient.Get().OrderBy(d => d.patientid);
            if (source.Any())
            {
                Patientview.DataSource = source;
                Patientview.DataBind();
            }
            else
            {
                Patientview.EmptyDataText = "No records found!!";
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (btnSubmit.Text == "Submit")
            {
                //add blood group ,type
                TBLpatient TBLpatient = new TBLpatient
                {
                     cardno = txtcardno.Text,
                    address = txtaddress.Text,
                    mobile = txtmobile.Text,
                    occupation = txtoccupation.Text,
                    name = txtname.Text, 
                    email = txtemail.Text 
                    
                };
                objUnitOfWork.Tblpatient.Insert(TBLpatient);
                if (objUnitOfWork.Save() > 0)
                {
                    lblMsg.Text = "Records successfully inserted";
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
            else if (btnSubmit.Text == "Edit")
            {
                TBLpatient TBLpatient = new TBLpatient();
                TBLpatient = objUnitOfWork.Tblpatient.GetByID(_patientID);

                TBLpatient.cardno = txtcardno.Text;
                TBLpatient.address = txtaddress.Text;
                TBLpatient.mobile = txtmobile.Text;
                TBLpatient.occupation = txtoccupation.Text;
                TBLpatient.name = txtname.Text;
                TBLpatient.email = txtemail.Text;
                objUnitOfWork.Tblpatient.Update(TBLpatient);

                if (objUnitOfWork.Save() > 0)
                {
                    lblMsg.Text = "Records successfully inserted";
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
            btnSubmit.Text = "Submit";
        }

        protected void lnkedit_Click(object sender, EventArgs e)
        {
            _patientID = int.Parse((((LinkButton)sender).CommandArgument).ToString());
            GridViewRow grdViewRow = (GridViewRow)((LinkButton)sender).Parent.Parent;
            txtname.Text = grdViewRow.Cells[0].Text;
            txtmobile.Text = grdViewRow.Cells[1].Text;
            txtemail.Text = grdViewRow.Cells[2].Text;
            txtaddress.Text = grdViewRow.Cells[3].Text;
            txtoccupation.Text = grdViewRow.Cells[4].Text;
            txtcardno.Text = grdViewRow.Cells[5].Text;
            btnSubmit.Text = "Edit";
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            _patientID = int.Parse((((LinkButton)sender).CommandArgument).ToString());
            objUnitOfWork.Tblpatient.Delete(_patientID);
            objUnitOfWork.Save();

        }
    }
}