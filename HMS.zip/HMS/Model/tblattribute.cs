﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.Spatial;

namespace HMS.Model
{
    [Table("tblattribute")]
    public partial class tblattribute
    {
        [Key]
        public int attributrid { get; set; }
        [StringLength(100)]
        public string attribute { get; set; }
        public string attributeqty { get; set; }
    }
}