namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("tbltreatment")]
    public partial class tbltreatment
    {
        [Key]
        public int treatmentid { get; set; }

        public int? appointmentid { get; set; }

        public DateTime? treatmentdate { get; set; }

        public virtual ICollection<tblappointment> tblappointment { get; set; }
        public virtual ICollection<tbladmitdetail> tbladmitdetails { get; set; }
        public virtual ICollection<tbltherapydetail> tbltherapydetails { get; set; }
        public virtual ICollection<tbltreatmentdetail> tbltreatmentdetails { get; set; }

        public virtual tblappointment tblappointments { get; set; }
        public virtual tbladmitdetail tbladmitdetail { get; set; }
        public virtual tbltherapydetail tbltherapydetail { get; set; }

    }
}
