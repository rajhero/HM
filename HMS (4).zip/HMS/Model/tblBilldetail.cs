namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class tblBilldetail
    {
        [Key]
        public int Billdetailsid { get; set; }

        public int? billid { get; set; }

        public int? item { get; set; }

        public int? qty { get; set; }

        public decimal? price { get; set; }

        public decimal? cgst { get; set; }

        public decimal? sgst { get; set; }

        public virtual tblbill tblbill { get; set; }
    }
}
