namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("tbltreatment")]
    public partial class tbltreatment
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public tbltreatment()
        {
            tbltreatmentdetails = new HashSet<tbltreatmentdetail>();
        }

        [Key]
        public int treatmentid { get; set; }

        public int? patientid { get; set; }

        public DateTime? treatmentdate { get; set; }

        public virtual TBLpatient TBLpatient { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tbltreatmentdetail> tbltreatmentdetails { get; set; }
    }
}
