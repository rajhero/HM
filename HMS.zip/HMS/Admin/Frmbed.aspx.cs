﻿using HMS.DAL;
using HMS.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HMS.Admin
{
    
    public partial class Frmbed : System.Web.UI.Page
    {

        private static int _bedID;

        public static int bedID { get => _bedID; set => _bedID = value; }
        private UnitOfWork objUnitOfWork = new UnitOfWork();
        private ServiceModel objServiceModel = new ServiceModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["controllerID"] != null)
            {
                if (!this.IsPostBack)
                {
                    Getbeddetails(); Clear();
                }
            }
        }

        private void Clear() { txtBedNumber.Text = string.Empty;ddlbedtype.SelectedIndex = ddlroom.SelectedIndex = 0; }

        private void Getbeddetails()
        {
            var source = objUnitOfWork.tblbedtypeRepository.Get().OrderBy(d => d.bedtypeid);
            bool any = source.Any();

            if (!any)
            {
                Bedview.EmptyDataText = "No records found!!";
            }
            else
            {
                if (Bedview != null)
                {
                    Bedview.DataSource = source;
                    Bedview.DataBind();
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (btnSubmit.Text == "Submit")
            {
                tblbed tblbed = new tblbed
                {
                    bedtype = ddlbedtype.SelectedItem.Value,
                    bedno= Convert.ToInt32(txtBedNumber.Text),
                    roomid = Convert.ToInt32(ddlroom.SelectedItem.Value),
                    

                };
                objUnitOfWork.tblbedRepository.Insert(tblbed);
                if (objUnitOfWork.Save() > 0)
                {
                    Getbeddetails();
                    lblMsg.Text = "Records successfully inserted";
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
            else if (btnSubmit.Text == "Edit")
            {
                tblbed tblbed = new tblbed();
                tblbed = objUnitOfWork.tblbedRepository.GetByID(bedID);
                tblbed.bedtype = ddlbedtype.SelectedItem.Value;
                tblbed.bedno = Convert.ToInt32(txtBedNumber.Text);
                tblbed.roomid = Convert.ToInt32(ddlroom.SelectedItem.Value);
                objUnitOfWork.tblbedRepository.Update(tblbed);
                if (objUnitOfWork.Save() > 0)
                {
                    lblMsg.Text = "Records successfully inserted";
                    Getbeddetails();
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
            btnSubmit.Text = "Submit";
        }

        protected void lnkedit_Click(object sender, EventArgs e)
        {
            bedID = int.Parse((((LinkButton)sender).CommandArgument).ToString());
            GridViewRow grdViewRow = (GridViewRow)((LinkButton)sender).Parent.Parent;
            txtBedNumber.Text = grdViewRow.Cells[0].Text;
            ddlbedtype.SelectedIndex = ddlbedtype.Items.IndexOf(ddlbedtype.Items.FindByValue(grdViewRow.Cells[0].Text));
            txtBedNumber.Text =  grdViewRow.Cells[0].Text;
            ddlroom.SelectedIndex = ddlroom.Items.IndexOf(ddlroom.Items.FindByValue(grdViewRow.Cells[0].Text));
            btnSubmit.Text = "Edit";
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            bedID = int.Parse((((LinkButton)sender).CommandArgument).ToString());


            objUnitOfWork.tblbedRepository.Delete(bedID);
            if (objUnitOfWork.Save() > 0)
            {
                lblMsg.Text = "Records successfully removed";
                Getbeddetails();
            }
            else { lblMsg.Text = "Server Interrupted!!"; }

        }
    }
}