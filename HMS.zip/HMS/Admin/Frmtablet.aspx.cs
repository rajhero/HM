﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HMS.DAL;
using HMS.Model;
namespace HMS.Admin
{
    public partial class Frmtablet : System.Web.UI.Page
    {

        private static int _itemID;

        public static int ItemID { get { return _itemID; } set { _itemID = value; } }
        private UnitOfWork objUnitOfWork = new UnitOfWork();
        private ServiceModel objServiceModel = new ServiceModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["controllerID"] != null)
            {
                if (!this.IsPostBack)
                {
                    GetItemdetails(); Clear();
                    filldeptartment();
                }
            }
        }
        private void filldeptartment()
        {
            var source = objUnitOfWork.tbldepartmentRepository.Get();

            if (source.Any())
            {

                ddldepartment.DataSource = source;
                ddldepartment.DataTextField = "departmentname";
                ddldepartment.DataValueField = "departmentID";
                ddldepartment.DataBind();
            }
            ddldepartment.Items.Insert(0, "Select");
        }
        private void getitemtype(int deptid)
        {
            var source = objUnitOfWork.tblItemtypeRepository.Get().Where(d=>d.departmentid== deptid).ToList();
            
            if (source.Any())
            {

                ddlItemtype.DataSource = source;
                ddlItemtype.DataTextField = "itemtype";
                ddlItemtype.DataValueField = "itemtypeid";
                ddlItemtype.DataBind();
            }
            ddlItemtype.Items.Insert(0, "Select");
        }

        private void Clear() { txtItemName.Text = txtitemdescription.Text= string.Empty; ddlItemtype.SelectedIndex = 0; }

        private void GetItemdetails()
        {
            var tablet = objUnitOfWork.tblitemRepository.Get()
                .Join(objServiceModel.tblItemtypes,Item=>Item.itemtypeid,itemty=>itemty.itemtypeid,(Item, itemty) =>new
                { itemid = Item.itemid,
                    item =Item.item,
                    itemdescription = Item.itemdescription,
                    itemtypeid =itemty.itemtypeid,
                    itemtype =itemty.itemtype
                })
                .OrderBy(d => d.itemid);
            bool any = tablet.Any();

            if (!any)
            {
                Tabletview.EmptyDataText = "No records found!!";
            }
            else
            {
                if (Tabletview != null)
                {
                    Tabletview.DataSource = tablet;
                    Tabletview.DataBind();
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (btnSubmit.Text == "Submit")
            {
                tblitem TBLtablet = new tblitem
                {
                    item = txtItemName.Text,
                   itemdescription= txtitemdescription.Text,
                   itemtypeid=Convert.ToInt32(ddlItemtype.SelectedItem.Value)
                };
                objUnitOfWork.tblitemRepository.Insert(TBLtablet);
                if (objUnitOfWork.Save() > 0)
                {
                    GetItemdetails();
                    lblMsg.Text = "Records successfully inserted";
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
            else if (btnSubmit.Text == "Edit")
            {
                tblitem TBLtablet = new tblitem();
                TBLtablet = objUnitOfWork.tblitemRepository.GetByID(ItemID);

                TBLtablet.item = txtItemName.Text;
                TBLtablet.itemdescription = txtitemdescription.Text;
                TBLtablet.itemtypeid = Convert.ToInt32(ddlItemtype.SelectedItem.Value);


                objUnitOfWork.tblitemRepository.Update(TBLtablet);
                if (objUnitOfWork.Save() > 0)
                {
                    lblMsg.Text = "Records successfully Updated";
                    GetItemdetails();
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
            btnSubmit.Text = "Submit";
        }

        protected void lnkedit_Click(object sender, EventArgs e)
        {
            ItemID = int.Parse((((LinkButton)sender).CommandArgument).ToString());
            GridViewRow grdViewRow = (GridViewRow)((LinkButton)sender).Parent.Parent;
            txtItemName.Text = grdViewRow.Cells[3].Text;
            txtitemdescription.Text = grdViewRow.Cells[4].Text;
            ddlItemtype.SelectedIndex = ddlItemtype.Items.IndexOf(ddlItemtype.Items.FindByValue( grdViewRow.Cells[1].Text));
            btnSubmit.Text = "Edit";
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            ItemID = int.Parse((((LinkButton)sender).CommandArgument).ToString());


            objUnitOfWork.tblitemRepository.Delete(ItemID);
            if (objUnitOfWork.Save() > 0)
            {
                lblMsg.Text = "Records successfully removed";
                GetItemdetails();
            }
            else { lblMsg.Text = "Server Interrupted!!"; }

        }

        protected void ddldepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddldepartment.SelectedIndex>0)
            {
                getitemtype(Convert.ToInt32(ddldepartment.SelectedItem.Value));
            }
        }
    }
}