namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("tblbill")]
    public partial class tblbill
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public tblbill()
        {
            tblBilldetails = new HashSet<tblBilldetail>();
        }

        [Key]
        public int billid { get; set; }

        public int purchaseid { get; set; }

        public DateTime billdate { get; set; }

        public decimal? taxpercent { get; set; }

        public decimal? total { get; set; }

        public decimal? discount { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tblBilldetail> tblBilldetails { get; set; }

        public virtual tblpurchase tblpurchase { get; set; }
    }
}
