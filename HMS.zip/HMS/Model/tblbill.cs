namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("tblbill")]
    public partial class tblbill
    {
        [Key]
        public int billid { get; set; }

        public int purchaseid { get; set; }

        public DateTime billdate { get; set; }

        public decimal? taxpercent { get; set; }

        public decimal? total { get; set; }

        public decimal? discount { get; set; }

        public virtual tblpurchase tblpurchase { get; set; }
    }
}
