﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace HMS.Model
{
    [Table("tblBilldetails")]
    public class tblBillDetails
    {
        [Key]
        public int Billdetailsid;
        public int billid;
        public int item;
        public int qty;
        public decimal price;
        public decimal cgst;
        public decimal sgst;

        public virtual ICollection<tblbill> tblbillCollection { get; set; }
       
        public virtual tblbill tblbill { get; set; }
       


    }
}