﻿using HMS.DAL;
using HMS.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HMS.Receptionist
{
    public partial class FRMpurchase : System.Web.UI.Page
    {

        private static int _enquiryid;

        public static int Enquiryid { get => _enquiryid; set => _enquiryid = value; }
        private UnitOfWork objUnitOfWork = new UnitOfWork();
        private ServiceModel objServiceModel = new ServiceModel();
        private string userid;
        public static int _selectedOrderid = 0;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["controllerID"] != null)
            {
                if (!this.IsPostBack)
                {
                    userid = Session["controllerID"].ToString();
                    Getorder();                     
                }
            }
        }
        private void Getorder()
        {
            var source = objUnitOfWork.tblorder.Get().Where(f => objUnitOfWork.tblpurchase.Get().Select(d=>d.orderid).ToList().Contains(f.Orderid) ==false).OrderBy(d => d.orderdate).Reverse();
            if (source.Any())
            {
               grdviewOrder .DataSource = source.ToList();
                grdviewOrder.DataBind();
            }
            else
            {
                grdviewOrder.EmptyDataText = "No records found!!";
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (btnSubmit.Text == "Submit")
            {

                tblpurchase tblpurchase = new tblpurchase
                {


                    orderid = _selectedOrderid,
                    purchasedate = DateTime.Now,
                    userid = Session["controllerID"].ToString(),
                    photcopy = ""



                };
                objUnitOfWork.tblpurchase.Insert(tblpurchase);
                if (objUnitOfWork.Save() > 0)
                {
                    if (grdviewOrderdetails.Rows.Count>0)
                    {
                        for (int i = 0; i < grdviewOrderdetails.Rows.Count; i++)
                        {
                         //int Orderid =Convert.ToInt32( grdviewOrderdetails.Rows[i].Cells[2].Text);
                         //int   orderdetailsid = Convert.ToInt32(grdviewOrderdetails.Rows[i].Cells[2].Text);
                          int  tablet = Convert.ToInt32(grdviewOrderdetails.Rows[i].Cells[2].Text);

                            //int  qty = Convert.ToInt32(grdviewOrderdetails.Rows[i].Cells[4].Text);
                            TextBox txtReceivedqty = (TextBox)grdviewOrderdetails.Rows[i].Cells[4].FindControl("txtReceivedqty");

                          
                            DropDownList ddlAttribute = (DropDownList)grdviewOrderdetails.Rows[i].Cells[5].FindControl("ddlAttribute");
                            string Attribute = ddlAttribute.SelectedItem.Value;
                            TextBox txtReceivedrate = (TextBox)grdviewOrderdetails.Rows[i].Cells[4].FindControl("txtReceivedrate");

                            int ReceivedQuantity = Convert.ToInt32(txtReceivedqty.Text);
                            decimal ReceivedRate =Convert.ToDecimal(txtReceivedrate.Text);
                            TextBox txtexpdate = (TextBox)grdviewOrderdetails.Rows[i].Cells[4].FindControl("txtexpdate");
                            TextBox txtmanufacturedate = (TextBox)grdviewOrderdetails.Rows[i].Cells[4].FindControl("txtmanufacturedate");
                            TextBox txtbatchno = (TextBox)grdviewOrderdetails.Rows[i].Cells[4].FindControl("txtbatchno");


                            
                            
                          DateTime  ExpireDate = DateTime.Parse(txtexpdate.Text);
                            DateTime ManufactureDate = DateTime.Parse(txtmanufacturedate.Text);
                          int  Batchno = Convert.ToInt32(txtbatchno.Text);

                            tblpurchasedetail tblpurchasedetail = new tblpurchasedetail
                            {

                                purchaseid = tblpurchase.purchaseid,
                                tablet = tablet,
                                qty = ReceivedQuantity,
                                rate = ReceivedRate,
                                type = Attribute,
                                batchno=Batchno.ToString(),
                                expdate=ExpireDate,
                                manufacturedate=ManufactureDate,
                               // photcopy="",



                            };
                            objUnitOfWork.tblpurchasedetail.Insert(tblpurchasedetail); 
                        }
                        if (objUnitOfWork.Save() > 0)
                        {
                            lblMsg.Text = "Records successfully inserted";
                        }
                        else { lblMsg.Text = "Server Interrupted!!"; }
                    }
                    lblMsg.Text = "Records successfully inserted";
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
            else if (btnSubmit.Text == "Edit")
            {
                

                if (objUnitOfWork.Save() > 0)
                {
                    lblMsg.Text = "Records successfully inserted";
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            
            btnSubmit.Text = "Submit";
        }

       

        protected void grdviewOrder_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow row = grdviewOrder.SelectedRow;
         
            int orderid = Convert.ToInt32(this.grdviewOrder.DataKeys[row.RowIndex].Values[0]);
            int distributorid = Convert.ToInt32(this.grdviewOrder.DataKeys[row.RowIndex].Values[1]);
            _selectedOrderid = orderid;//Convert.ToInt32(row.Cells[0].Text);
            var source = objUnitOfWork.tblorderdetail.Get().Where(d=>d.orderid== orderid);
            if (source.Any())
            {
                grdviewOrderdetails.DataSource = source;
                grdviewOrderdetails.DataBind();
            }
            else
            {
                grdviewOrderdetails.EmptyDataText = "No records found!!";
            }
        }

        protected void grdviewOrderdetails_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DropDownList ddlAttribute = (e.Row.FindControl("ddlAttribute") as DropDownList);
                if (ddlAttribute!=null)
                {
                    var source = objUnitOfWork.TblattributeRepository.Get();
                    if (source.Any())
                    {
                        ddlAttribute.DataSource = source;
                        ddlAttribute.DataTextField = "attribute";
                        ddlAttribute.DataValueField = "attributrid";
                        ddlAttribute.DataBind();
                    }
                    else
                    {
                        ddlAttribute.Items.Insert(0,"No records found!!");
                    }
                    ddlAttribute.Items.Insert(0, "Select");

                }

            }
        }

        protected void ddlAttribute_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList ddlAttribute = (DropDownList)sender;
            if (ddlAttribute!=null)
            {
                int _attrid = Convert.ToInt32(ddlAttribute.SelectedItem.Value);
                var source = objUnitOfWork.TblattributeRepository.Get().Where(d=>d.attributrid== _attrid);
                Label lblattrqty = (Label)grdviewOrder.FindControl("lblattrqty");
                if (lblattrqty!=null)
                {
                    lblattrqty.Text = source.FirstOrDefault().attributeqty.ToString(); 
                }

            }
        }
    }
}