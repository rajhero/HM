namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("TBLItems")]
    public partial class TBLItem1
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public TBLItem1()
        {
            tblorderdetails = new HashSet<tblorderdetail>();
            tbltreatmenttabletdetails = new HashSet<tbltreatmenttabletdetail>();
        }

        [Key]
        public int itemid { get; set; }

        public string item { get; set; }

        public string itemdescription { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tblorderdetail> tblorderdetails { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tbltreatmenttabletdetail> tbltreatmenttabletdetails { get; set; }
    }
}
