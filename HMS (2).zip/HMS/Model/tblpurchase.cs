namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("tblpurchase")]
    public partial class tblpurchase
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public tblpurchase()
        {
            tblbills = new HashSet<tblbill>();
            tblpurchasedetails = new HashSet<tblpurchasedetail>();
        }

        [Key]
        public int purchaseid { get; set; }

        public int orderid { get; set; }

        public DateTime? purchasedate { get; set; }

        [StringLength(50)]
        public string userid { get; set; }

        public string photcopy { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tblbill> tblbills { get; set; }

        public virtual tblorder tblorder { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tblpurchasedetail> tblpurchasedetails { get; set; }
    }
}
