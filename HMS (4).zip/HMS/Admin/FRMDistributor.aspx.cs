﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HMS.DAL;
using HMS.Model;

namespace HMS.Admin
{
    public partial class FRMDistributor : System.Web.UI.Page
    {

        private static int _distributorID;

        public static int DistributorID { get { return _distributorID; } set { _distributorID = value; } }
        private UnitOfWork objUnitOfWork = new UnitOfWork();
        private ServiceModel objServiceModel = new ServiceModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["controllerID"] != null)
            {
                if (!this.IsPostBack)
                {

                    GetTbldistributordetail(); Clear();
                }
            }
        }

        private void Clear() => txtcompanyname.Text =
        txtemail.Text = 
        txtaddress.Text =
        txtcompanymobile.Text = 
        txtcontactperson.Text = 
        txtpocmobile.Text = string.Empty;

        private void GetTbldistributordetail(int id=0)
        {
            if (id == 0)
            {
                var source = objUnitOfWork.Tbldistributordetail.Get().OrderBy(d => d.distributorid);
                if (source.Any())
                {
                    distributorview.DataSource = source;
                    distributorview.DataBind();
                }
                else
                {
                    distributorview.EmptyDataText = "No records found!!";
                }
            }
            else {
                var source = objUnitOfWork.Tbldistributordetail.Get().Where(d=>d.distributorid==id).OrderBy(d => d.distributorid);
                if (source.Any())
                {
                    GridView1.DataSource = source;
                    GridView1.DataBind();
                }
                else
                {
                    GridView1.EmptyDataText = "No records found!!";
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (btnSubmit.Text == "Submit")
            {
                TBLdistributordetail TBLdistributordetail = new TBLdistributordetail
                {

                    address = txtaddress.Text,
                    companymobile = txtcompanymobile.Text,
                    contactperson = txtcontactperson.Text,
                    companyname = txtcompanyname.Text,
                    email = txtemail.Text,
                    pocmobile = txtpocmobile.Text
                };
                objUnitOfWork.Tbldistributordetail.Insert(TBLdistributordetail);
                if (objUnitOfWork.Save() > 0)
                {
                    lblMsg.Text = "Records successfully inserted";
                    GetTbldistributordetail(TBLdistributordetail.distributorid);Clear();
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
            else if (btnSubmit.Text == "Edit")
            {
                TBLdistributordetail TBLdistributordetail = new TBLdistributordetail();
                TBLdistributordetail = objUnitOfWork.Tbldistributordetail.GetByID(_distributorID);

                TBLdistributordetail.address = txtaddress.Text;
                TBLdistributordetail.companymobile = txtcompanymobile.Text;
                TBLdistributordetail.contactperson = txtcontactperson.Text;
                TBLdistributordetail.companyname = txtcompanyname.Text;
                TBLdistributordetail.email = txtemail.Text;
                TBLdistributordetail.pocmobile = txtpocmobile.Text;
                objUnitOfWork.Tbldistributordetail.Update(TBLdistributordetail);
                if (objUnitOfWork.Save() > 0)
                {
                    lblMsg.Text = "Records successfully inserted";
                    GetTbldistributordetail(TBLdistributordetail.distributorid); Clear();
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
            btnSubmit.Text = "Submit";
        }

        protected void lnkedit_Click(object sender, EventArgs e)
        {
            _distributorID = int.Parse((((LinkButton)sender).CommandArgument).ToString());
            GridViewRow grdViewRow = (GridViewRow)((LinkButton)sender).Parent.Parent;
            txtcompanyname.Text = grdViewRow.Cells[0].Text;
            txtemail.Text = grdViewRow.Cells[1].Text;
            txtaddress.Text = grdViewRow.Cells[2].Text;
            txtcompanymobile.Text = grdViewRow.Cells[3].Text;
            txtcontactperson.Text = grdViewRow.Cells[4].Text;
            txtpocmobile.Text = grdViewRow.Cells[5].Text;
            btnSubmit.Text = "Edit";
            MultiView1.SetActiveView(addview);
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            _distributorID = int.Parse((((LinkButton)sender).CommandArgument).ToString());
            objUnitOfWork.Tbldistributordetail.Delete(_distributorID);
            objUnitOfWork.Save();

        }

        protected void btnaddview_Click(object sender, EventArgs e)
        {
            MultiView1.SetActiveView(addview);
        }

        protected void btndisplay_Click(object sender, EventArgs e)
        {
           
            MultiView1.SetActiveView(displayview);
        }
    }
}