﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HMS.DAL;
using HMS.Model;

namespace HMS.Receptionist
{
    public partial class FRMenquirydetails : System.Web.UI.Page
    {

        private static int _enquiryid;

        public static int Enquiryid { get => _enquiryid; set => _enquiryid = value; }
        private UnitOfWork objUnitOfWork = new UnitOfWork();
        private ServiceModel objServiceModel = new ServiceModel();
        private string userid;
        protected void Page_Init(object sender, EventArgs e)
        {
            txtuserid.Enabled = false;

        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["controllerID"] != null)
            {
                if (!this.IsPostBack)
                {
                    userid = Session["controllerID"].ToString();
                    GetTbldistributordetail(); Clear();
                    txtuserid.Text = userid;
                }
            }
        }

        private void Clear() => txtname.Text =
        txtemail.Text =
        txtaddress.Text =
        txtmobile.Text =
        txtoccupation.Text =
        txtleadby.Text = txtleadcontact.Text = txtuserid.Text = txtreason.Text = string.Empty;

        private void GetTbldistributordetail()
        {
            var source = objUnitOfWork.tblenquiry.Get().OrderBy(d => d.enquiryid);
            if (source.Any())
            {
                Enquiryview.DataSource = source;
                Enquiryview.DataBind();
            }
            else
            {
                Enquiryview.EmptyDataText = "No records found!!";
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (btnSubmit.Text == "Submit")
            {
                 
                tblenquiry tblenquiry = new tblenquiry
                {
                    name = txtname.Text,
                    email = txtemail.Text,
                    address = txtaddress.Text,
                    mobile = txtmobile.Text,
                    occupation = txtoccupation.Text,
                    leadby = txtleadby.Text,
                    leadcontact = txtleadcontact.Text,
                    userid = txtuserid.Text,
                    reason = txtreason.Text

                };
                objUnitOfWork.tblenquiry.Insert(tblenquiry);
                if (objUnitOfWork.Save() > 0)
                {
                    lblMsg.Text = "Records successfully inserted";
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
            else if (btnSubmit.Text == "Edit")
            {
                tblenquiry tblenquiry = new tblenquiry();
                tblenquiry = objUnitOfWork.tblenquiry.GetByID(_enquiryid);

                tblenquiry.name = txtname.Text;
                tblenquiry.email = txtemail.Text;
                tblenquiry.address = txtaddress.Text;
                tblenquiry.mobile = txtmobile.Text;
                tblenquiry.occupation = txtoccupation.Text;
                tblenquiry.leadby = txtleadby.Text;
                tblenquiry.leadcontact = txtleadcontact.Text;
                tblenquiry.leadaddress = txtleadaddress.Text;
                tblenquiry.userid = userid;
                tblenquiry.reason = txtreason.Text;
                objUnitOfWork.tblenquiry.Update(tblenquiry);

                if (objUnitOfWork.Save() > 0)
                {
                    lblMsg.Text = "Records successfully inserted";
                }
                else { lblMsg.Text = "Server Interrupted!!"; }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
            btnSubmit.Text = "Submit";
        }

        protected void lnkedit_Click(object sender, EventArgs e)
        {
            _enquiryid = int.Parse((((LinkButton)sender).CommandArgument).ToString());
            GridViewRow grdViewRow = (GridViewRow)((LinkButton)sender).Parent.Parent;
            txtname.Text = grdViewRow.Cells[0].Text;
            txtmobile.Text = grdViewRow.Cells[1].Text;
            txtemail.Text = grdViewRow.Cells[2].Text;
            txtaddress.Text = grdViewRow.Cells[3].Text;
            txtoccupation.Text = grdViewRow.Cells[4].Text;
            txtreason.Text = grdViewRow.Cells[5].Text;
            txtleadby.Text = grdViewRow.Cells[6].Text;
            txtleadcontact.Text = grdViewRow.Cells[7].Text;
            txtleadaddress.Text = grdViewRow.Cells[8].Text;
            txtuserid.Text = grdViewRow.Cells[9].Text;


            btnSubmit.Text = "Edit";
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            _enquiryid = int.Parse((((LinkButton)sender).CommandArgument).ToString());
            objUnitOfWork.tblenquiry.Delete(_enquiryid);
            objUnitOfWork.Save();

        }
    }
}