﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HMS.Receptionist
{
    public partial class FRMPurchasedetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void lnkedit_Click(object sender, EventArgs e)
        {
            _enquiryid = int.Parse((((LinkButton)sender).CommandArgument).ToString());
            GridViewRow grdViewRow = (GridViewRow)((LinkButton)sender).Parent.Parent;
            txtname.Text = grdViewRow.Cells[0].Text;
            txtmobile.Text = grdViewRow.Cells[1].Text;
            txtemail.Text = grdViewRow.Cells[2].Text;
            txtaddress.Text = grdViewRow.Cells[3].Text;
            txtoccupation.Text = grdViewRow.Cells[4].Text;
            txtreason.Text = grdViewRow.Cells[5].Text;
            txtleadby.Text = grdViewRow.Cells[6].Text;
            txtleadcontact.Text = grdViewRow.Cells[7].Text;
            txtleadaddress.Text = grdViewRow.Cells[8].Text;
            txtuserid.Text = grdViewRow.Cells[9].Text;


            btnSubmit.Text = "Edit";
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            _enquiryid = int.Parse((((LinkButton)sender).CommandArgument).ToString());
            objUnitOfWork.tblenquiry.Delete(_enquiryid);
            objUnitOfWork.Save();

        }
    }
}