namespace HMS.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("tblorder")]
    public partial class tblorder
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public tblorder()
        {
            tblorderdetails = new HashSet<tblorderdetail>();
        }

        [Key]
        public int Orderid { get; set; }

        public int distributorid { get; set; }

        public DateTime? orderdate { get; set; }

        [StringLength(50)]
        public string receiverid { get; set; }

        [StringLength(50)]
        public string receivedrate { get; set; }

        public string photcopy { get; set; }

        public virtual TBLaccount TBLaccount { get; set; }

        public virtual TBLdistributordetail TBLdistributordetail { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<tblorderdetail> tblorderdetails { get; set; }
    }
}
