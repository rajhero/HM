﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HMS.Model;
using HMS.DAL;
 

namespace HMS
{
    public partial class Default : System.Web.UI.Page
    {
         
         
        /// <inheritdoc />
        public enum Cases:int
        {
           [StringValue("~/Admin/AdminHome.aspx") ] admin=1,
            [StringValue("~/Admin/AdminHome.aspx")] reseptionist = 2,
            [StringValue("~/Admin/AdminHome.aspx")] doctor = 3,
            [StringValue("~/Admin/AdminHome.aspx")] superadmin = 4

        }

        private UnitOfWork objUnitOfWork = new UnitOfWork();
        private ServiceModel objServiceModel = new ServiceModel();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Clear(); 
            }
        }

        public void Clear() => Txtusername.Text = TxtPassword.Text = string.Empty;

        public Cases obj = Cases.admin;
        protected void BtnLogin_Click(object sender, EventArgs e)
        {
            var os = objUnitOfWork.TblaccountRepository;
           TBLaccount TbLaccount= os.GetByID(Txtusername.Text);
            
            if (TbLaccount.password != null && TbLaccount.loginID != null &&
                string.Equals(TbLaccount.loginID, Txtusername.Text, StringComparison.InvariantCulture) && string.Equals(
                    a: TbLaccount.password, b: TxtPassword.Text,
                    comparisonType: StringComparison.InvariantCulture))
            {
                switch (obj)
                {
                    case  Cases.admin: Response.Redirect(StringValueAttribute.GetStringValue(Cases.admin));
                        break;
                    case Cases.doctor:
                        Response.Redirect(StringValueAttribute.GetStringValue(Cases.doctor));
                        break;
                    case Cases.reseptionist:
                        Response.Redirect(StringValueAttribute.GetStringValue(Cases.reseptionist));
                        break;
                    case Cases.superadmin:
                        Response.Redirect(StringValueAttribute.GetStringValue(Cases.superadmin));
                        break;

                }

            }
        }
    }
}